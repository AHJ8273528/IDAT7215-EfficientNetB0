"""Read published results without installing TensorFlow; --verify audits predictions."""
import argparse,csv,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--verify',action='store_true');a=p.parse_args()
    if a.verify:
        subprocess.run([sys.executable,str(ROOT/'code/verify.py'),'--root',str(ROOT)],check=True)
        if (ROOT/'quality_upgrade/verification.json').exists():subprocess.run([sys.executable,str(ROOT/'quality_upgrade/code/quality_verify.py'),'--root',str(ROOT)],check=True)
    with (ROOT/'three_seed_summary.csv').open(newline='') as f:summary=list(csv.DictReader(f))
    choice=json.loads((ROOT/'results/selection.json').read_text())
    print('\nEfficientNetB0 — recommendations selected on validation only\n')
    for study in ['one','two','three']:
        v=choice['recommended_variant'][study];o=choice['optimizer'][f'{study}:{v}'];r=next(x for x in summary if x['study']==study and x['variant']==v and x['optimizer']==o)
        print(f"Study {study}: {v}, {o}; test accuracy {100*float(r['accuracy_mean']):.2f}% ± {100*float(r['accuracy_sd']):.2f} SD; defect recall {100*float(r['recall_mean']):.2f}%")
    print('\nThese are known public image-level test sets, not blind tests on new prints.')
    if (ROOT/'quality_upgrade/summary.json').exists():
        q=json.loads((ROOT/'quality_upgrade/summary.json').read_text())
        print(f"Corrected reference accuracy: {100*q['corrected_reference_accuracy']:.2f}%; local median latency ratio {q['local_median_latency_ratio']:.2f}.")
        print(f"Experimental gate: coverage {100*q['quality_gate_test_coverage']:.2f}%, accepted error {100*q['quality_gate_test_accepted_error']:.2f}%. Rejected inputs are not correct predictions.")
    print('Class order: normal=0, defect=1. Supplied peer probabilities retain defect=0.')
if __name__=='__main__':main()
