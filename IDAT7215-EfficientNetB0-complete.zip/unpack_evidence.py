"""Expand the supplied archive after SHA-256 verification, preserving existing files."""
import hashlib,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ARCHIVE=ROOT/'full_evidence.zip'
EXPECTED='ddd2e05a18392eeb8e164c60038fde4745d23ed611f3867cbca6955c9822b199'
assert hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()==EXPECTED,'Evidence checksum mismatch'
with zipfile.ZipFile(ARCHIVE) as z:
    for info in z.infolist():
        rel=Path(info.filename)
        assert not rel.is_absolute() and '..' not in rel.parts
        assert rel.suffix in ['.csv','.json','.txt']
        dest=ROOT/rel
        if dest.exists():continue
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(z.read(info))
print('Expanded prediction/metric evidence. Run python main.py --verify and python robustness_upgrade/verify_robustness.py')
