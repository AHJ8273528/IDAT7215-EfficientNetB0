"""Audit published predictions using only the Python standard library."""
import argparse
import csv
import hashlib
import json
import statistics
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'code'))
from verify import calculate, compare, read


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=HERE.parent)
    args = p.parse_args()
    r = args.root / 'robustness_upgrade'
    protocol = json.loads((r / 'protocol.json').read_text())
    sha = hashlib.sha256((r / 'protocol.json').read_bytes()).hexdigest()
    split = read(args.root / 'manifests/three_split.csv')
    groups = {s: {x['path']: int(x['class_id']) for x in split if x['split']==s}
              for s in ('train', 'validation', 'test')}
    metrics = read(r / 'metrics.csv')
    total = 0
    for part in ('validation', 'test'):
        predictions = read(r / f'{part}_predictions.csv')
        for row in [x for x in metrics if x['split']==part]:
            chosen = [x for x in predictions if all(x[k]==row[k] for k in ('arm','seed','condition'))]
            compare(calculate(chosen, groups[part]), row)
            for x in chosen:
                a, b = float(x['normal_probability']), float(x['defect_probability'])
                assert -1e-7 <= a <= 1.0000001 and -1e-7 <= b <= 1.0000001
                assert abs(a+b-1) < 2e-6
                assert int(x['predicted_class']) == int(b > a)
            total += len(chosen)
    assert len(metrics) == 84 and total == (159+309)*7*6
    validation = {}
    for arm in ('clean', 'augmented'):
        selected = [x for x in metrics if x['split']=='validation' and x['arm']==arm]
        validation[arm] = dict(mean_f1=statistics.mean(float(x['f1']) for x in selected),
                               clean_f1=statistics.mean(float(x['f1']) for x in selected if x['condition']=='clean'),
                               worst_recall=min(statistics.mean(float(x['recall']) for x in selected if x['condition']==c) for c in protocol['conditions']))
    b, c = validation['clean'], validation['augmented']
    adopt = c['mean_f1'] >= b['mean_f1']+.01 and c['clean_f1'] >= b['clean_f1'] and c['worst_recall'] >= b['worst_recall']
    selection = json.loads((r / 'selection.json').read_text())
    assert selection['adopt_augmentation'] == adopt
    assert selection['selected_arm'] == ('augmented' if adopt else 'clean')
    assert selection['protocol_sha256'] == sha
    for arm in ('clean', 'augmented'):
        for seed in (42,43,44):
            run = json.loads((r / f'runs/{arm}/{seed}/run.json').read_text())
            history = read(r / f'runs/{arm}/{seed}/history.csv')
            assert run['protocol_sha256']==sha and run['updates']==1110
            assert run['epochs']==len(history)==30 and run['images_per_epoch']==1089 and run['batch_size']==30
            assert run['head_parameters']==82114
    checks = json.loads((r / 'model_checks.json').read_text())
    assert checks['total_parameters']==4131685
    assert checks['cached_direct_max_error'] < 1e-5 and checks['reload_max_error'] < 1e-6
    assert checks['raw_image_coverage']==1
    result = dict(passed=True, metric_rows=len(metrics), prediction_rows=total, fits=6,
                  protocol_sha256=sha, adoption_recomputed_from_validation_only=True,
                  test_images=309, reuse_warning='Three seeds and seven perturbations reuse the same309 test images; not6489 independent tests.',
                  method='Independent metric/label/probability and validation-rule recomputation; no model training rerun.')
    (r / 'verification.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__=='__main__':
    main()
