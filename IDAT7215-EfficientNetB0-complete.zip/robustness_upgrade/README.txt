Robustness upgrade v3 — matched-control experiment

The augmentation candidate passed the fixed validation adoption rule.
Six fresh classifier fits: two arms × seeds42/43/44. Frozen EfficientNetB0,
GAP + fixed LayerNorm + Dense64/dropout0.5/Dense2, Adam0.001, 30epochs,
batch30, 1089training images/epoch, 1110optimizer updates per run.
Each arm receives the same image order and initial head weights. The augmented
arm selects one of clean/blur/JPEG/low-resolution/rotation per image per epoch.
No validation/test image is used as a training sample.

Three-seed mean StudyThree test accuracy:
Clean: 99.78% -> 100.00%
Dark: 99.89% -> 99.57%
Bright: 98.38% -> 99.14%
Blur: 73.79% -> 99.89%
JPEG 15: 92.77% -> 98.81%
Low resolution: 88.78% -> 100.00%
Rotate 10°: 90.18% -> 100.00%
Mean accuracy over seven conditions: 91.94% -> 99.63%.
The same309 images are reused across conditions and seeds.
Total parameters remain4,131,685. Every image receives a prediction; no
abstention, quality gate, TTA, or ensemble is used for these results.

Selection was saved before this extension's test feature extraction. The entire
extension was designed after earlier public stress results had been seen.
The transformations and strengths overlap training and test, so this measures
robustness to those known synthetic corruption types. It is not a blind test,
new-print test, or proof of robustness to arbitrary camera conditions.
Dark-image accuracy falls slightly versus the matched clean control; all
conditions are reported. Historical v2 results and checkpoints remain unchanged.
This v3 upgrade concerns StudyThree; it does not replace StudyOne's selection.

Files:
protocol.json: frozen experiment and selection rules.
selection.json: validation-only adoption, before test feature extraction.
metrics.csv, summary.csv: all84 metric rows and28 three-seed summaries.
validation_predictions.csv, test_predictions.csv: all19,656 predictions.
selected_seed42.keras: full single-view model, fixed seed42.
model_checks.json: cached/direct/reloaded inference agreement.
verification.json: independent standard-library prediction and selection audit.

Reproduce from the parent repository root:
python robustness_upgrade/run_robustness.py --data work/data --base-cache work/features --cache work/robust_features --output work/robust_reproduced
Prerequisite: run the core feature cache using code/experiment.py. See root README.
Audit supplied results without TensorFlow:
python robustness_upgrade/verify_robustness.py
Predict a raw image:
python code/predict.py --model robustness_upgrade/selected_seed42.keras --image IMAGE_PATH
