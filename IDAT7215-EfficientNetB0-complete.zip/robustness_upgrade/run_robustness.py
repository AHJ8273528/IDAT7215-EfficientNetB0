"""Matched six-fit, validation-selected robustness extension. See protocol.json."""
import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '2')
import numpy as np
import tensorflow as tf

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'code'))
sys.path.insert(0, str(ROOT / 'quality_upgrade/code'))
from experiment import dataset, pixels, make_head, scores, prediction_rows, write_csv, save_json
from stress_tta import transform


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--base-cache', type=Path, required=True)
    parser.add_argument('--cache', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=HERE)
    a = parser.parse_args()
    a.output.mkdir(parents=True, exist_ok=True)
    a.cache.mkdir(parents=True, exist_ok=True)
    protocol = json.loads((HERE / 'protocol.json').read_text())
    identity = digest(HERE / 'protocol.json')
    tf.config.threading.set_intra_op_parallelism_threads(4)
    tf.config.threading.set_inter_op_parallelism_threads(2)
    tf.config.experimental.enable_op_determinism()
    tf.keras.utils.set_random_seed(42)
    rows, paths, y, split = dataset(a.data, ROOT / 'manifests', 'three')
    base_features = np.load(a.base_cache / 'three/corrected.npz')['gap_norm']
    assert len(base_features) == len(rows)
    split_sha = digest(ROOT / 'manifests/three_split.csv')
    base_meta = json.loads((a.base_cache / 'three/corrected.json').read_text())
    assert base_meta['split_sha256'] == split_sha
    backbone = tf.keras.applications.EfficientNetB0(include_top=False, weights='imagenet', input_shape=(224, 224, 3))
    backbone.trainable = False
    pooled = tf.keras.layers.GlobalAveragePooling2D()(backbone.output)
    encoder = tf.keras.Model(backbone.input, pooled)

    @tf.function(input_signature=[tf.TensorSpec((None, 224, 224, 3), tf.float32)])
    def encode(x):
        return encoder(x, training=False)

    def features(part, condition):
        ix = split[part]
        if condition == 'clean':
            return base_features[ix]
        dest = a.cache / f'{part}_{condition}.npz'
        if dest.exists():
            loaded = np.load(dest)
            assert str(loaded['split_sha']) == split_sha
            assert str(loaded['condition']) == condition
            return loaded['features']
        result = []
        before = time.perf_counter()
        for first in range(0, len(ix), 24):
            images = pixels([paths[i] for i in ix[first:first+24]]).astype(np.uint8)
            changed = transform(images, condition).astype(np.float32)
            result.append(encode(changed).numpy())
        value = np.concatenate(result)
        np.savez_compressed(dest, features=value, split_sha=split_sha, condition=condition)
        print('CACHE', part, condition, value.shape, round(time.perf_counter()-before, 1), 'seconds', flush=True)
        return value

    train_x = np.stack([features('train', c) for c in protocol['training_views']])
    val_x = {c: features('validation', c) for c in protocol['conditions']}
    train_y = tf.keras.utils.to_categorical(y[split['train']], 2)
    train_tensor = tf.constant(train_x)
    target_tensor = tf.constant(train_y)
    n = len(split['train'])
    batch = protocol['batch_size']
    steps = int(np.ceil(n / batch))
    epochs = protocol['epochs']
    options = tf.data.Options()
    options.threading.private_threadpool_size = 1
    histories = []
    for seed in protocol['seeds']:
        order_rng = np.random.default_rng(seed)
        orders = np.stack([order_rng.permutation(n) for _ in range(epochs)])
        view_rng = np.random.default_rng(seed + 10000)
        views = view_rng.integers(0, len(protocol['training_views']), size=(epochs, n), dtype=np.int32)
        schedule_file = a.cache / f'schedule_{seed}.npz'
        np.savez_compressed(schedule_file, orders=orders, augmented_views=views)
        init_reference = None
        for arm in ('clean', 'augmented'):
            dest = a.output / 'runs' / arm / str(seed)
            record = dest / 'run.json'
            if record.exists():
                assert json.loads(record.read_text())['protocol_sha256'] == identity
                continue
            dest.mkdir(parents=True, exist_ok=True)
            tf.keras.backend.clear_session()
            tf.keras.utils.set_random_seed(seed)
            head = make_head('gap_norm', seed)
            initial = head.get_weights()
            if arm == 'clean':
                init_reference = initial
            elif init_reference is not None:
                for p, q in zip(init_reference, initial, strict=True):
                    np.testing.assert_array_equal(p, q)
            view_schedule = views if arm == 'augmented' else np.zeros_like(views)
            indices = tf.constant(np.stack([view_schedule, orders], axis=-1), dtype=tf.int32)

            def get_batch(number):
                epoch = number // steps
                start = (number % steps) * batch
                selected = indices[epoch, start:tf.minimum(start+batch, n)]
                return tf.gather_nd(train_tensor, selected), tf.gather(target_tensor, selected[:, 1])

            ds = tf.data.Dataset.range(epochs * steps).map(get_batch).with_options(options).prefetch(1)
            head.compile(optimizer=tf.keras.optimizers.Adam(protocol['learning_rate']),
                         loss='binary_crossentropy', metrics=['accuracy'])
            before = time.perf_counter()
            history = head.fit(ds, epochs=epochs, steps_per_epoch=steps, verbose=0).history
            updates = int(head.optimizer.iterations.numpy())
            assert updates == epochs * steps
            head.save(dest / 'head.keras')
            write_csv(dest / 'history.csv', [dict(epoch=i+1, **{k: float(v[i]) for k,v in history.items()}) for i in range(epochs)])
            save_json(record, dict(protocol_sha256=identity, split_sha256=split_sha, arm=arm,
                                  seed=seed, updates=updates, epochs=epochs, images_per_epoch=n,
                                  batch_size=batch, head_parameters=head.count_params(),
                                  schedule_sha256=digest(schedule_file), seconds=time.perf_counter()-before))
            print('FIT', arm, seed, 'updates', updates, 'seconds', round(time.perf_counter()-before, 1), flush=True)
    metrics = []
    predictions = []
    def evaluate(part, feature_map):
        ix = split[part]
        for arm in ('clean', 'augmented'):
            for seed in protocol['seeds']:
                head = tf.keras.models.load_model(a.output / f'runs/{arm}/{seed}/head.keras', compile=False)
                for condition in protocol['conditions']:
                    p = head(feature_map[condition], training=False).numpy()
                    metrics.append(dict(split=part, arm=arm, seed=seed, condition=condition, **scores(y[ix], p)))
                    predictions.extend(dict(split=part, arm=arm, seed=seed, condition=condition, **r)
                                       for r in prediction_rows([rows[i] for i in ix], y[ix], p))
        write_csv(a.output / f'{part}_metrics.csv', [r for r in metrics if r['split'] == part])
        write_csv(a.output / f'{part}_predictions.csv', [r for r in predictions if r['split'] == part])
    evaluate('validation', val_x)
    val_summary = {}
    for arm in ('clean', 'augmented'):
        chosen = [r for r in metrics if r['arm'] == arm]
        val_summary[arm] = dict(mean_f1=float(np.mean([r['f1'] for r in chosen])),
                               clean_f1=float(np.mean([r['f1'] for r in chosen if r['condition'] == 'clean'])),
                               worst_recall=min(float(np.mean([r['recall'] for r in chosen if r['condition'] == c])) for c in protocol['conditions']))
    b, c = val_summary['clean'], val_summary['augmented']
    adopt = c['mean_f1'] >= b['mean_f1'] + .01 and c['clean_f1'] >= b['clean_f1'] and c['worst_recall'] >= b['worst_recall']
    selection = dict(adopt_augmentation=bool(adopt), selected_arm='augmented' if adopt else 'clean',
                     validation=val_summary, protocol_sha256=identity, rule=protocol['selection'],
                     scope=protocol['scope'])
    save_json(a.output / 'selection.json', selection)
    selection_digest = digest(a.output / 'selection.json')
    print('SELECTION', json.dumps(selection), flush=True)
    # Selection is persisted before any new test feature extraction or prediction.
    test_x = {c: features('test', c) for c in protocol['conditions']}
    evaluate('test', test_x)
    assert digest(a.output / 'selection.json') == selection_digest
    write_csv(a.output / 'metrics.csv', metrics)
    summary = []
    for part in ('validation', 'test'):
        for arm in ('clean', 'augmented'):
            for condition in protocol['conditions']:
                chosen = [r for r in metrics if r['split']==part and r['arm']==arm and r['condition']==condition]
                summary.append(dict(split=part, arm=arm, condition=condition, runs=len(chosen),
                                    accuracy_mean=float(np.mean([r['accuracy'] for r in chosen])),
                                    accuracy_sd=float(np.std([r['accuracy'] for r in chosen], ddof=1)),
                                    recall_mean=float(np.mean([r['recall'] for r in chosen])),
                                    f1_mean=float(np.mean([r['f1'] for r in chosen]))))
    write_csv(a.output / 'summary.csv', summary)
    head = tf.keras.models.load_model(a.output / f'runs/{selection["selected_arm"]}/42/head.keras', compile=False)
    model = tf.keras.Model(backbone.input, head(pooled), name='efficientnetb0_robust_seed42')
    selected = split['test'][:4]
    images = pixels([paths[i] for i in selected])
    cached = head(base_features[selected], training=False).numpy()
    direct = model(images, training=False).numpy()
    np.testing.assert_allclose(cached, direct, atol=1e-5, rtol=1e-5)
    model.save(a.output / 'selected_seed42.keras')
    restored = tf.keras.models.load_model(a.output / 'selected_seed42.keras', compile=False)
    reloaded = restored(images, training=False).numpy()
    np.testing.assert_allclose(direct, reloaded, atol=1e-6, rtol=1e-5)
    save_json(a.output / 'model_checks.json', dict(total_parameters=model.count_params(),
              head_parameters=head.count_params(), cached_direct_max_error=float(np.max(np.abs(cached-direct))),
              reload_max_error=float(np.max(np.abs(direct-reloaded))), seed=42, arm=selection['selected_arm'],
              raw_image_coverage=1.0, threshold=.5, output_columns=['normal', 'defect'],
              input='float32 RGB224 in[0,255]; single view; no quality rejection',
              protocol_sha256=identity, selection_sha256=selection_digest,
              tensorflow=tf.__version__, keras=tf.keras.__version__))
    print('DONE selected', selection['selected_arm'], 'parameters', model.count_params(), flush=True)


if __name__ == '__main__':
    main()
