"""Run the published stages in dependency order into a separate output folder."""
import argparse,shutil,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',type=Path,required=True);p.add_argument('--cache',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--skip-download',action='store_true');a=p.parse_args()
    if a.output.resolve()==HERE:raise ValueError('Use a separate output directory to preserve the supplied historical results.')
    a.output.mkdir(parents=True,exist_ok=True)
    for name in ['manifests','peer_evidence']:
        shutil.copytree(HERE/name,a.output/name,dirs_exist_ok=True)
    shutil.copy2(HERE/'protocol.json',a.output/'protocol.json')
    shutil.copy2(HERE/'main.py',a.output/'main.py')
    shutil.copytree(HERE/'code',a.output/'code',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
    def run(name,*args):
        cmd=[sys.executable,str(HERE/'code'/name),*map(str,args)];print('RUN',name,flush=True);subprocess.run(cmd,check=True)
    if not a.skip_download:run('prepare_data.py','--data',a.data)
    run('experiment.py','--data',a.data,'--cache',a.cache,'--output',a.output/'results','--stage','all')
    run('audit_data.py','--data',a.data,'--output',a.output/'audit')
    run('validate_spatial.py','--cache',a.cache,'--root',a.output)
    run('export_models.py','--data',a.data,'--cache',a.cache,'--root',a.output)
    run('model_checks.py','--output',a.output/'models/model_structure_checks.json')
    run('explain.py','--data',a.data,'--root',a.output)
    run('summarize.py','--root',a.output)
    run('verify.py','--root',a.output)
if __name__=='__main__':main()
