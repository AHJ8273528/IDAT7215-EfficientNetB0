"""Offline integrity and arithmetic verification, Python standard library only."""
import argparse,csv,hashlib,json,math
from collections import defaultdict,Counter
from pathlib import Path
from statistics import mean

def read(path):
    with path.open(newline='') as f:return list(csv.DictReader(f))
def ranked_auc(y,score):
    ordered=sorted(zip(score,y));rank_sum=0.;i=0
    while i<len(ordered):
        j=i+1
        while j<len(ordered) and ordered[j][0]==ordered[i][0]:j+=1
        rank_sum+=sum(v for _,v in ordered[i:j])*(i+1+j)/2;i=j
    p=sum(y);n=len(y)-p;return (rank_sum-p*(p+1)/2)/(p*n)
def ap(y,score):
    ordered=sorted(zip(score,y),reverse=True);i=tp=0;value=0.;p=sum(y)
    while i<len(ordered):
        j=i+1
        while j<len(ordered) and ordered[j][0]==ordered[i][0]:j+=1
        pos=sum(v for _,v in ordered[i:j]);tp+=pos;value+=pos/p*tp/j;i=j
    return value
def calculate(rows,expected):
    assert len(rows)==len(expected)==len({r['path'] for r in rows})
    assert {r['path'] for r in rows}==set(expected)
    y=[];hat=[];score=[]
    for r in rows:
        truth=int(r['true_class']);pred=int(r['predicted_class']);p0=float(r['normal_probability']);p1=float(r['defect_probability'])
        assert truth==expected[r['path']] and truth in [0,1]
        assert all(math.isfinite(p) and 0<=p<=1 for p in [p0,p1]) and math.isclose(p0+p1,1,abs_tol=1e-5)
        assert pred==int(p1>p0)
        y.append(truth);hat.append(pred);score.append(p1)
    tp=sum(a==b==1 for a,b in zip(y,hat));tn=sum(a==b==0 for a,b in zip(y,hat));fp=sum(a==0 and b==1 for a,b in zip(y,hat));fn=len(y)-tp-tn-fp
    d=lambda a,b:a/b if b else 0.;n=len(y);acc=(tp+tn)/n;pe=((tp+fp)*(tp+fn)+(tn+fn)*(tn+fp))/n**2
    return dict(n=n,correct=tp+tn,tp=tp,tn=tn,fp=fp,fn=fn,accuracy=acc,balanced_accuracy=(d(tp,tp+fn)+d(tn,tn+fp))/2,precision=d(tp,tp+fp),recall=d(tp,tp+fn),f1=d(2*tp,2*tp+fp+fn),roc_auc=ranked_auc(y,score),average_precision=ap(y,score),mcc=d(tp*tn-fp*fn,math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))),kappa=d(acc-pe,1-pe))
def compare(actual,reported):
    for k,v in actual.items():assert math.isclose(v,float(reported[k]),abs_tol=1e-9,rel_tol=1e-9),(k,v,reported[k])

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=p.parse_args();root=a.root
    protocol=json.loads((root/'protocol.json').read_text());identity=hashlib.sha256((root/'protocol.json').read_bytes()).hexdigest();metricrows=read(root/'results/metrics.csv');validated=[];run_count=0
    for study in ['one','two','three']:
        manifest=read(root/f'manifests/{study}_split.csv');labels={x['path']:int(x['class_id']) for x in manifest}
        assert len(manifest)==len(labels)
        assert all(int(x['class_id'])==int(x['label'] in ['badcylinder','Badaug','defected']) for x in manifest)
        groups={s:{x['path']:int(x['class_id']) for x in manifest if x['split']==s} for s in ['train','validation','test']}
        assert not set(groups['train'])&set(groups['test']) and not set(groups['train'])&set(groups['validation'])
        splitsha=hashlib.sha256((root/f'manifests/{study}_split.csv').read_bytes()).hexdigest()
        for variant in ['legacy','ap4','gap_norm','gap_repeat','spatial_pyramid']:
            for opt in ['Adam','SGD','RMSprop']:
                for seed in ([42] if variant=='legacy' else [42,43,44]):
                    dest=root/f'results/{study}/{variant}/{opt}/{seed}';run=json.loads((dest/'run.json').read_text());c=run['config'];run_count+=1
                    assert c['protocol_sha256']==identity and c['split_sha256']==splitsha
                    assert c['study']==study and c['variant']==variant and c['optimizer']==opt and c['seed']==seed
                    assert c['epochs']==protocol['studies'][study]['epochs'] and c['batch_size']==protocol['studies'][study]['batch_size']
                    assert run['updates']==math.ceil(len(groups['train'])/c['batch_size'])*c['epochs']
                    assert [int(x['epoch']) for x in read(dest/'history.csv')]==list(range(1,c['epochs']+1))
                    for split in ['train','validation','test']:
                        actual=calculate(read(dest/f'{split}_predictions.csv'),groups[split])
                        if split=='validation':reported=run['validation']
                        else:reported=next(x for x in metricrows if x['study']==study and x['variant']==variant and x['optimizer']==opt and int(x['seed'])==seed and x['split']==split)
                        compare(actual,reported);validated.append(dict(study=study,variant=variant,optimizer=opt,seed=seed,split=split,**actual))
    assert run_count==117 and len(validated)==351
    selections=json.loads((root/'results/selection.json').read_text());variants=['ap4','gap_norm','gap_repeat','spatial_pyramid'];optimizers=['Adam','SGD','RMSprop']
    for study in ['one','two','three']:
        ranks=[]
        for variant in variants:
            matching=[r for r in validated if r['study']==study and r['variant']==variant and r['split']=='validation']
            avg={opt:{k:mean(x[k] for x in matching if x['optimizer']==opt) for k in ['f1','recall']} for opt in optimizers}
            best=sorted(optimizers,key=lambda o:(-avg[o]['f1'],-avg[o]['recall'],optimizers.index(o)))[0]
            assert selections['optimizer'][f'{study}:{variant}']==best
            params=409794 if variant in ['gap_repeat','spatial_pyramid'] else 82114
            ranks.append((-avg[best]['f1'],-avg[best]['recall'],params,variants.index(variant),variant))
        assert selections['recommended_variant'][study]==sorted(ranks)[0][-1]
    cvmetrics=read(root/'temporal_validation/metrics.csv');metadata={x['sample_id']:x for x in read(root/'manifests/blocked_cv_manifest.csv')};random={x['sample_id']:int(x['random_fold']) for x in read(root/'manifests/random_cv_assignments.csv')};active={name:x for name,x in metadata.items() if int(x['use_in_block_cv'])==1};cvcount=0
    assert len(active)==223
    for protocol_name in ['random','blocked']:
        block={name:(random[name] if protocol_name=='random' else int(x['time_block'])) for name,x in active.items()}
        for variant in ['ap4','spatial_pyramid']:
            for seed in [42,43,44]:
                tested=[]
                for fold in range(5):
                    train={name for name in active if block[name] not in [fold,(fold+1)%5]}
                    for split,target in [('test',fold),('validation',(fold+1)%5)]:
                        expected={name:int(active[name]['label']) for name in active if block[name]==target};assert not train&set(expected)
                        path=root/f'temporal_validation/{protocol_name}/{fold}/{variant}/{seed}/{split}_predictions.csv';rows=read(path)
                        actual=calculate(rows,expected);reported=next(x for x in cvmetrics if x['protocol']==protocol_name and x['variant']==variant and int(x['seed'])==seed and int(x['fold'])==fold and x['split']==split)
                        compare(actual,reported);cvcount+=1
                        if split=='test':tested.extend(x['path'] for x in rows)
                assert len(tested)==len(set(tested))==223
    for label in [0,1]:
        for fold in range(5):assert sum(int(x['label'])==label and int(x['time_block'])==fold for x in active.values())==sum(int(active[name]['label'])==label and block_id==fold for name,block_id in random.items())
        seq=sorted((int(x['sequence_rank']),int(x['time_block'])) for x in active.values() if int(x['label'])==label)
        assert all(b1==b2 or r2-r1>=7 for (r1,b1),(r2,b2) in zip(seq,seq[1:]))
    cross=read(root/'results/cross_domain.csv')
    for row in cross:
        manifest=read(root/f"manifests/{row['target']}_split.csv");expected={x['path']:int(x['class_id']) for x in manifest}
        pred=root/f"results/cross_domain/{row['source']}_to_{row['target']}/{row['variant']}/{row['seed']}_predictions.csv"
        compare(calculate(read(pred),expected),row)
    result=dict(passed=True,main_fits=run_count,main_metric_rows_recomputed=len(validated),temporal_fits=60,temporal_metric_rows_recomputed=cvcount,cross_domain_rows_recomputed=len(cross),selection_recomputed_using_validation_only=True,exact_epoch_and_update_budgets_verified=True,all_prediction_file_ids_and_semantic_labels_verified=True,matched_temporal_random_class_counts=True,temporal_boundary_rank_gap_minimum=7,scope='Saved-prediction consistency; does not turn related public images into an independent new-print test.')
    (root/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
