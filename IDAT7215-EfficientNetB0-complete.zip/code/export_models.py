"""Export selected inference models and check direct vs cached predictions."""
import argparse,json,time
from pathlib import Path
import numpy as np,tensorflow as tf
from experiment import dataset,pixels,read_csv,write_csv,save_json,make_head

def pooled_tensor(maps,variant):
    layers=tf.keras.layers
    if variant=='ap4':return layers.Flatten()(layers.AveragePooling2D(4)(maps))
    gap=layers.GlobalAveragePooling2D()(maps)
    if variant=='gap_norm':return gap
    if variant=='gap_repeat':return layers.Concatenate()([gap]*5)
    bins=[]
    for a,b in [(0,3),(3,7)]:
        for c,d in [(0,3),(3,7)]:
            crop=layers.Cropping2D(cropping=((a,7-b),(c,7-d)))(maps)
            bins.append(layers.GlobalAveragePooling2D()(crop))
    return layers.Concatenate()([gap]+bins)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--cache',type=Path,required=True);parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=parser.parse_args()
    result=a.root/'results';out=a.root/'models';out.mkdir(exist_ok=True)
    choices=json.loads((result/'selection.json').read_text());records=[]
    base=tf.keras.applications.EfficientNetB0(include_top=False,weights='imagenet',input_shape=(224,224,3));base.trainable=False
    for study in ['one','two','three']:
        rows,paths,y,splits=dataset(a.data,a.root/'manifests',study)
        variant=choices['recommended_variant'][study];opt=choices['optimizer'][f'{study}:{variant}']
        # Seed42 is fixed, not chosen by its test score.
        head=tf.keras.models.load_model(result/study/variant/opt/'42/head.keras',compile=False)
        full=tf.keras.Model(base.input,head(pooled_tensor(base.output,variant)),name=f'efficientnetb0_{study}_{variant}')
        test=splits['test'][:3];images=pixels([paths[i] for i in test])
        cached=np.load(a.cache/study/'corrected.npz')[variant][test]
        target=head(cached,training=False).numpy();direct=full(images,training=False).numpy()
        np.testing.assert_allclose(target,direct,atol=1e-5,rtol=1e-5)
        dest=out/f'{study}_selected_seed42.keras';full.save(dest)
        reload=tf.keras.models.load_model(dest,compile=False);loaded=reload(images,training=False).numpy()
        np.testing.assert_allclose(direct,loaded,atol=1e-6,rtol=1e-5)
        @tf.function(input_signature=[tf.TensorSpec((1,224,224,3),tf.float32)])
        def infer(x):return full(x,training=False)
        for _ in range(3):infer(images[:1]).numpy()
        times=[]
        for i in range(12):
            before=time.perf_counter();infer(images[i%3:i%3+1]).numpy();times.append((time.perf_counter()-before)*1000)
        records.append(dict(study=study,variant=variant,optimizer=opt,seed=42,backbone_parameters=base.count_params(),head_parameters=head.count_params(),total_parameters=full.count_params(),cached_direct_max_error=float(np.max(np.abs(target-direct))),reload_max_error=float(np.max(np.abs(direct-loaded))),median_ms=float(np.median(times)),p90_ms=float(np.percentile(times,90)),timing_n=12))
        print(records[-1],flush=True)
    write_csv(out/'models_and_checks.csv',records)
    save_json(out/'input_contract.json',dict(input_shape=['batch',224,224,3],input_dtype='float32',input_range=[0,255],channels='RGB',resize='OpenCV linear resize',output_columns=['normal','defect'],decision='argmax; fixed threshold equivalent except exact0.5 tie goes normal',selection='Variant and optimizer selected using validation three-seed mean F1, recall then fixed rules; saved model always seed42',timing='CPU, 4 TensorFlow intraop threads; single-image inference, 3 warmups, 12 timing samples, excluding file decoding. Peer timings are on another machine and are not used for speed-ratio claims.'))
    # Count the reference Inception architecture; no random model is evaluated for accuracy.
    del full,reload,base
    tf.keras.backend.clear_session()
    inception=tf.keras.applications.InceptionResNetV2(include_top=False,weights=None,input_shape=(224,224,3))
    inception.trainable=False
    h=tf.keras.layers.Flatten()(tf.keras.layers.AveragePooling2D(4)(inception.output))
    h=tf.keras.layers.Dense(64,activation='relu')(h);h=tf.keras.layers.Dropout(.5)(h);h=tf.keras.layers.Dense(2,activation='softmax')(h)
    ref=tf.keras.Model(inception.input,h)
    save_json(out/'reference_parameter_count.json',dict(model='InceptionResNetV2 with teammate AP4/Dense64/Dense2 head at224',backbone_parameters=inception.count_params(),total_parameters=ref.count_params(),method='Instantiated architecture with weights=None for exact parameter counting only; no Inception accuracy was trained or inferred here'))
if __name__=='__main__':main()
