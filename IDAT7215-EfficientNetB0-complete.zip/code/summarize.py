"""Rebuild concise comparison tables and figures from saved predictions/metrics."""
import argparse,csv,json
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score,recall_score,f1_score,roc_auc_score

def read(p):return list(csv.DictReader(p.open()))
def write(p,rows):
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);a=p.parse_args();r=a.root
    tests=[x for x in read(r/'results/metrics.csv') if x['split']=='test'];groups=defaultdict(list)
    for x in tests:groups[(x['study'],x['variant'],x['optimizer'])].append(x)
    summary=[]
    for (study,variant,opt),items in groups.items():
        item=dict(study=study,variant=variant,optimizer=opt,runs=len(items),head_parameters=int(items[0]['head_parameters']))
        for metric in ['accuracy','recall','f1','roc_auc']:
            v=[float(x[metric]) for x in items];item[metric+'_mean']=float(np.mean(v));item[metric+'_sd']=float(np.std(v,ddof=1)) if len(v)>1 else ''
        summary.append(item)
    write(r/'three_seed_summary.csv',summary)
    peer=[]
    for study in ['one','two','three']:
        for opt in ['Adam','SGD','RMSprop']:
            paths=read(r/f'peer_evidence/inception/{study}/{opt}/test_predictions.csv')
            # Convert by semantic directory name, never by another project's numeric label.
            y=np.array([x['label'] in ['badcylinder','Badaug','defected'] for x in paths],int)
            prob=np.array([float(x['probability_0']) for x in paths]);pred=np.array([x['prediction'] in ['badcylinder','Badaug','defected'] for x in paths],int)
            peer.append(dict(study=study,model='Peer InceptionResNetV2',optimizer=opt,runs=1,accuracy=accuracy_score(y,pred),recall=recall_score(y,pred),f1=f1_score(y,pred),auc=roc_auc_score(y,prob)))
            values=[]
            for seed in [42,43,44]:
                q=read(r/f'peer_evidence/msaf_v2m/{study}/{opt}/{seed}/test_predictions.csv')
                yy=np.array([int(x['true_class'])==0 for x in q],int);pp=np.array([float(x['defect_probability']) for x in q]);hat=np.array([int(x['predicted_class'])==0 for x in q],int)
                values.append([accuracy_score(yy,hat),recall_score(yy,hat),f1_score(yy,hat),roc_auc_score(yy,pp)])
            peer.append(dict(study=study,model='Peer MSAF-EfficientNetV2M',optimizer=opt,runs=3,**dict(zip(['accuracy','recall','f1','auc'],np.mean(values,axis=0)))))
    write(r/'peer_test_recomputed.csv',peer)
    paired=[]
    for study in ['one','two','three']:
        for opt in ['Adam','SGD','RMSprop']:
            for variant in ['ap4','gap_norm','gap_repeat','spatial_pyramid']:
                ours=next(x for x in summary if x['study']==study and x['optimizer']==opt and x['variant']==variant)
                for model in ['Peer InceptionResNetV2','Peer MSAF-EfficientNetV2M']:
                    other=next(x for x in peer if x['study']==study and x['optimizer']==opt and x['model']==model)
                    paired.append(dict(study=study,optimizer=opt,b0_variant=variant,peer_model=model,b0_accuracy=ours['accuracy_mean'],peer_accuracy=other['accuracy'],difference_pp=100*(ours['accuracy_mean']-other['accuracy']),b0_recall=ours['recall_mean'],peer_recall=other['recall']))
    write(r/'same_optimizer_comparison.csv',paired)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    colors=['#9ba9b5','#2a6f97','#24786e','#c88427']
    fig,axes=plt.subplots(1,2,figsize=(13,4.8))
    for ax,key,title in zip(axes,['accuracy','recall'],['Test accuracy — Adam','Defect recall — Adam']):
        x=np.arange(3);w=.21
        for j,(name,variant,model) in enumerate([('Peer Inception (1 seed)',None,'Peer InceptionResNetV2'),('B0 AP4 (3 seeds)','ap4',None),('B0 spatial pyramid (3 seeds)','spatial_pyramid',None),('Peer MSAF (3 seeds)',None,'Peer MSAF-EfficientNetV2M')]):
            vals=[100*float(next(z for z in (summary if variant else peer) if z['study']==s and z['optimizer']=='Adam' and (z['variant']==variant if variant else z['model']==model))[key+'_mean' if variant else key]) for s in ['one','two','three']]
            ax.bar(x+(j-1.5)*w,vals,w,label=name,color=colors[j]);
        ax.set_xticks(x,['Study One','Study Two','Study Three']);ax.set_ylim(75,103);ax.set_ylabel('% (axis starts at 75)');ax.set_title(title);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,ncol=2,loc='lower center',bbox_to_anchor=(.5,-.02));fig.suptitle('Same images and epoch/batch budgets; different architectures and software versions')
    fig.tight_layout(rect=[0,.1,1,.94]);fig.savefig(r/'three_study_comparison.png',dpi=180,bbox_inches='tight');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(12,4.7));variants=['ap4','gap_norm','gap_repeat','spatial_pyramid'];names=['AP4','GAP + norm','Repeat GAP\n(control)','Spatial\npyramid']
    for ax,key,title in zip(axes,['accuracy','recall'],['Study Three accuracy','Study Three defect recall']):
        x=np.arange(4)
        for j,opt in enumerate(['Adam','SGD','RMSprop']):
            vals=[100*next(z for z in summary if z['study']=='three' and z['variant']==v and z['optimizer']==opt)[key+'_mean'] for v in variants]
            sd=[100*next(z for z in summary if z['study']=='three' and z['variant']==v and z['optimizer']==opt)[key+'_sd'] for v in variants]
            ax.bar(x+(j-1)*.24,vals,.24,yerr=sd,capsize=3,label=opt,color=colors[j+1])
        ax.set_xticks(x,names);ax.set_ylim(0,106);ax.set_ylabel('%');ax.set_title(title);ax.grid(axis='y',alpha=.2);ax.set_axisbelow(True)
    axes[0].legend(loc='lower left');fig.suptitle('Fixed final epoch; bars = 3-seed mean, whiskers = sample SD (not confidence intervals)');fig.tight_layout();fig.savefig(r/'pooling_ablation.png',dpi=180);plt.close(fig)
    # Paired misses identify recovered defects and new misses without selecting a best test seed.
    miss=[]
    for study in ['one','two','three']:
        for seed in [42,43,44]:
            base={x['path']:x for x in read(r/f'results/{study}/ap4/Adam/{seed}/test_predictions.csv')}
            candidate=read(r/f'results/{study}/spatial_pyramid/Adam/{seed}/test_predictions.csv')
            for q in candidate:
                b=base[q['path']];assert b['true_class']==q['true_class']
                if b['predicted_class']!=q['predicted_class']:
                    miss.append(dict(study=study,seed=seed,path=q['path'],true_class=int(q['true_class']),ap4_prediction=int(b['predicted_class']),spatial_prediction=int(q['predicted_class']),ap4_defect_probability=float(b['defect_probability']),spatial_defect_probability=float(q['defect_probability'])))
    if miss:write(r/'paired_prediction_changes.csv',miss)
    if (r/'temporal_validation/summary.csv').exists():
        data=read(r/'temporal_validation/summary.csv');fig,ax=plt.subplots(figsize=(8,4.6));x=np.arange(2)
        for j,(v,label,color) in enumerate([('ap4','AP4',colors[1]),('spatial_pyramid','Spatial pyramid',colors[2])]):
            vals=[100*float(next(z for z in data if z['protocol']==p and z['variant']==v)['mean_fold_accuracy']) for p in ['random','blocked']]
            ax.bar(x+(j-.5)*.28,vals,.28,label=label,color=color)
            for k,value in enumerate(vals):ax.text(x[k]+(j-.5)*.28,value+.6,f'{value:.2f}',ha='center')
        ax.set_xticks(x,['Matched random folds','Time blocks with boundary gaps']);ax.set_ylim(0,107);ax.set_ylabel('Mean fold accuracy (%)');ax.legend(loc='lower left')
        ax.set_title('Same 223 images, matched class counts; 5 folds × 3 seeds\nWithin-session validation, not new-print testing');fig.tight_layout();fig.savefig(r/'temporal_comparison.png',dpi=180);plt.close(fig)
    print(json.dumps({'three_seed_groups':len(summary),'peer_groups_recomputed':len(peer),'same_optimizer_comparisons':len(paired),'paired_prediction_changes':len(miss)},indent=2))
if __name__=='__main__':main()
