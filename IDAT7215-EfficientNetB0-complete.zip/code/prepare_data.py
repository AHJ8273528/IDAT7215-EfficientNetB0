"""Download public datasets and verify the teammate-supplied SHA-256 manifest.

The manifest and shared split CSVs are attributed to the supplied group archive.
No teammate Python is imported or executed by this package.
"""
import argparse, csv, hashlib, shutil, time, urllib.parse, urllib.request, zipfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
REV = '52fe75dec70c1e8046493b4e3256f8f752a4d39d'
AM = 'AMdataset-' + REV
KAGGLE_URL = 'https://www.kaggle.com/api/v1/datasets/download/justin900429/3d-printer-defected-dataset?datasetVersionNumber=1'
KAGGLE_SHA = 'a24229ab7f3f4802fb7e0316b373f2b915b1faf30b00c45143479eacfaab9bcd'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576), b''): h.update(block)
    return h.hexdigest()

def download(url, path, expected=None):
    if path.exists() and (expected is None or sha(path)==expected): return
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.part')
    for attempt in range(4):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'IDAT7215-research'})
            with urllib.request.urlopen(req,timeout=120) as src,tmp.open('wb') as dst:
                shutil.copyfileobj(src,dst)
            if expected and sha(tmp)!=expected:raise ValueError('SHA-256 mismatch: '+str(path))
            tmp.replace(path);return
        except Exception:
            tmp.unlink(missing_ok=True)
            if attempt==3:raise
            time.sleep(2**attempt)

def local_path(data,row):
    path=Path(row['path'])
    if path.is_absolute() or '..' in path.parts:raise ValueError('Unsafe manifest path')
    if row['study'] in ('one','two'):return data/'AMdataset'/Path(*path.parts[1:])
    return data/path

def prepare(data, manifest, originals=None):
    rows=list(csv.DictReader(manifest.open()))
    if originals:
        for row in rows:
            if row['study']!='one':continue
            rel=Path(*Path(row['path']).parts[2:]);src=originals/rel;dst=local_path(data,row)
            if src.exists() and sha(src)==row['sha256'] and not dst.exists():
                dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    missing=[r for r in rows if not local_path(data,r).exists() or sha(local_path(data,r))!=r['sha256']]
    am=[r for r in missing if r['study'] in ('one','two')]
    def one(row):
        rel='/'.join(Path(row['path']).parts[1:])
        download(f'https://raw.githubusercontent.com/mahsan2/AMdataset/{REV}/'+urllib.parse.quote(rel),local_path(data,row),row['sha256'])
    with ThreadPoolExecutor(max_workers=8) as pool:
        for i,_ in enumerate(pool.map(one,am),1):
            if i%250==0 or i==len(am):print('Verified AM files',i,'/',len(am),flush=True)
    three=[r for r in missing if r['study']=='three']
    if three:
        archive=data/'downloads'/'study3-v1.zip';download(KAGGLE_URL,archive,KAGGLE_SHA)
        with zipfile.ZipFile(archive) as z:
            for row in three:
                member='/'.join(Path(row['path']).parts[1:]);dest=local_path(data,row)
                dest.parent.mkdir(parents=True,exist_ok=True)
                with z.open(member) as src,dest.open('wb') as dst:shutil.copyfileobj(src,dst)
                if sha(dest)!=row['sha256']:raise ValueError('Image checksum mismatch')
    assert all(sha(local_path(data,r))==r['sha256'] for r in rows)
    print('PASS: all',len(rows),'image hashes verified.',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',required=True,type=Path)
    p.add_argument('--manifest',type=Path,default=HERE/'manifests/assets_manifest.csv')
    p.add_argument('--originals',type=Path,help='Optional existing AMdataset/dataset directory')
    a=p.parse_args();prepare(a.data,a.manifest,a.originals)
