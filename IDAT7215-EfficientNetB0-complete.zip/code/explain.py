"""Matched qualitative Grad-CAM and deterministic success/failure case selection."""
import argparse,json
from pathlib import Path
import cv2,numpy as np,tensorflow as tf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from experiment import read_csv,write_csv,pixels,pool,dataset

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--data',type=Path,required=True);a=p.parse_args();r=a.root
    paths={}
    records={}
    for v in ['ap4','spatial_pyramid']:
        records[v]={x['path']:x for x in read_csv(r/f'results/three/{v}/Adam/42/test_predictions.csv')}
    cases=[]
    for title,condition in [
        ('Recovered defect',lambda y,b,c:y==1 and b==0 and c==1),
        ('New missed defect',lambda y,b,c:y==1 and b==1 and c==0),
        ('Both missed defect',lambda y,b,c:y==1 and b==0 and c==0),
        ('Both detected defect',lambda y,b,c:y==1 and b==1 and c==1),
        ('Both normal',lambda y,b,c:y==0 and b==0 and c==0)]:
        eligible=[name for name in sorted(records['ap4']) if condition(int(records['ap4'][name]['true_class']),int(records['ap4'][name]['predicted_class']),int(records['spatial_pyramid'][name]['predicted_class']))]
        if eligible:cases.append((title,eligible[0]))
    base=tf.keras.applications.EfficientNetB0(include_top=False,weights='imagenet',input_shape=(224,224,3));base.trainable=False
    heads={v:tf.keras.models.load_model(r/f'results/three/{v}/Adam/42/head.keras',compile=False) for v in records}
    logits={v:tf.keras.Model(h.input,h.get_layer('logits').output) for v,h in heads.items()}
    fig,axes=plt.subplots(len(cases),3,figsize=(10,3.4*len(cases)),squeeze=False);evidence=[]
    for row,(title,name) in enumerate(cases):
        rgb=pixels([a.data/'study3'/name]);maps=base(rgb,training=False);axes[row,0].imshow(rgb[0].astype(np.uint8));axes[row,0].set_title(title+'\n'+name,fontsize=10)
        result=dict(path=name,outcome=title)
        for column,v in enumerate(['ap4','spatial_pyramid'],1):
            with tf.GradientTape() as tape:
                tape.watch(maps);features=pool(maps)[v];z=logits[v](features,training=False);margin=z[:,1]-z[:,0]
            grad=tape.gradient(margin,maps);assert grad is not None
            heat=tf.nn.relu(tf.reduce_sum(maps*tf.reduce_mean(grad,axis=(1,2),keepdims=True),axis=-1))[0].numpy()
            heat=heat/max(float(heat.max()),1e-10)
            prob=heads[v](features,training=False).numpy()[0,1]
            np.testing.assert_allclose(tf.nn.softmax(z).numpy()[0,1],prob,atol=1e-6)
            np.testing.assert_allclose(prob,float(records[v][name]['defect_probability']),atol=2e-4,rtol=2e-4)
            axes[row,column].imshow(rgb[0].astype(np.uint8));axes[row,column].imshow(cv2.resize(heat,(224,224)),cmap='turbo',alpha=.42,vmin=0,vmax=1)
            axes[row,column].set_title(f'{v}: p(defect)={prob:.4f}',fontsize=11);result[v+'_defect_probability']=float(prob)
        for ax in axes[row]:ax.axis('off')
        evidence.append(result)
    fig.suptitle('Study Three, Adam, seed42 — first path in each available outcome group\nGrad-CAM of defect-minus-normal logit margin; qualitative attribution, not defect masks',fontsize=12)
    fig.tight_layout(rect=[0,0,1,.95]);fig.savefig(r/'gradcam_cases.png',dpi=160);plt.close(fig)
    write_csv(r/'gradcam_cases.csv',evidence)
    print(json.dumps({'cases':len(cases),'logit_probability_and_saved_prediction_checks':'passed'},indent=2))
if __name__=='__main__':main()
