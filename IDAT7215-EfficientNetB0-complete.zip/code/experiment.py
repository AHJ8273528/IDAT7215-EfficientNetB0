"""Frozen EfficientNetB0: shared three-Study splits and spatial pooling ablations.

Run stages cache, train, evaluate in that order. The training stage never reads
test labels for selection. All historical/public tests remain exploratory.
"""
import argparse, csv, hashlib, json, os, time
from pathlib import Path
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','2')
import cv2
import numpy as np
import tensorflow as tf
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, precision_score,
    recall_score, f1_score, roc_auc_score, average_precision_score, confusion_matrix,
    matthews_corrcoef, cohen_kappa_score)

HERE=Path(__file__).resolve().parents[1]
VARIANTS=('ap4','gap_norm','gap_repeat','spatial_pyramid')
OPTS={'Adam':tf.keras.optimizers.Adam,'SGD':tf.keras.optimizers.SGD,'RMSprop':tf.keras.optimizers.RMSprop}

def read_csv(path):
    with Path(path).open(newline='') as f:return list(csv.DictReader(f))

def write_csv(path, rows):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.with_suffix('.tmp').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    path.with_suffix('.tmp').replace(path)

def save_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n')

def dataset(data,manifest,study):
    rows=read_csv(manifest/f'{study}_split.csv')
    folder={'one':data/'AMdataset/dataset','two':data/'AMdataset/Augmented_data','three':data/'study3'}[study]
    paths=[folder/r['path'] for r in rows]
    y=np.array([int(r['class_id']) for r in rows],np.int32)
    assert len(set(r['path'] for r in rows))==len(rows)
    split={s:np.flatnonzero([r['split']==s for r in rows]) for s in ['train','validation','test']}
    assert sum(map(len,split.values()))==len(rows)
    assert all(set(y[ix])=={0,1} for ix in split.values())
    return rows,paths,y,split

def pixels(paths):
    batch=[]
    for p in paths:
        bgr=cv2.imread(str(p))
        if bgr is None:raise ValueError('Missing or undecodable image: '+str(p))
        batch.append(cv2.resize(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB),(224,224)))
    return np.asarray(batch,np.float32)

def pool(maps):
    # 7x7 = [0:3,3:7] in each dimension. No pixel is discarded at a border.
    assert tuple(maps.shape[1:])==(7,7,1280)
    ap4=tf.reduce_mean(maps[:,:4,:4],axis=(1,2))
    gap=tf.reduce_mean(maps,axis=(1,2))
    bins=[tf.reduce_mean(maps[:,a:b,c:d],axis=(1,2))
          for a,b in [(0,3),(3,7)] for c,d in [(0,3),(3,7)]]
    return {'ap4':ap4,'gap_norm':gap,'gap_repeat':tf.concat([gap]*5,axis=1),
            'spatial_pyramid':tf.concat([gap]+bins,axis=1)}

def make_head(variant,seed):
    n=6400 if variant in ('spatial_pyramid','gap_repeat') else 1280
    inputs=tf.keras.Input((n,),name='pooled_features');x=inputs
    if variant not in ('ap4','legacy'):
        pieces=[x[:,i:i+1280] for i in range(0,n,1280)]
        pieces=[tf.keras.layers.LayerNormalization(center=False,scale=False,epsilon=1e-5,name=f'norm_{i}')(v) for i,v in enumerate(pieces)]
        x=pieces[0] if len(pieces)==1 else tf.keras.layers.Concatenate()(pieces)
    x=tf.keras.layers.Dense(64,activation='relu',kernel_initializer=tf.keras.initializers.GlorotUniform(seed),name='hidden')(x)
    x=tf.keras.layers.Dropout(.5,seed=seed)(x)
    logits=tf.keras.layers.Dense(2,kernel_initializer=tf.keras.initializers.GlorotUniform(seed+1000),name='logits')(x)
    return tf.keras.Model(inputs,tf.keras.layers.Softmax()(logits),name=variant)

def scores(y,p):
    pred=p.argmax(axis=1);tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel()
    # Wilson interval remains nonzero at 100%; independent-image assumption is a limitation.
    n=len(y);a=accuracy_score(y,pred);z=1.959963984540054;den=1+z*z/n
    mid=(a+z*z/(2*n))/den;half=z*np.sqrt(a*(1-a)/n+z*z/(4*n*n))/den
    return dict(n=n,correct=int((pred==y).sum()),tn=int(tn),fp=int(fp),fn=int(fn),tp=int(tp),
       accuracy=float(a),balanced_accuracy=balanced_accuracy_score(y,pred),precision=precision_score(y,pred,zero_division=0),
       recall=recall_score(y,pred,zero_division=0),f1=f1_score(y,pred,zero_division=0),
       roc_auc=roc_auc_score(y,p[:,1]),average_precision=average_precision_score(y,p[:,1]),
       mcc=matthews_corrcoef(y,pred),kappa=cohen_kappa_score(y,pred),wilson_low=float(mid-half),wilson_high=float(mid+half))

def prediction_rows(rows,y,p):
    return [dict(path=r['path'],true_class=int(label),predicted_class=int(prob.argmax()),
        normal_probability=float(prob[0]),defect_probability=float(prob[1]))
        for r,label,prob in zip(rows,y,p,strict=True)]

def cache_features(args,studies):
    base=tf.keras.applications.EfficientNetB0(include_top=False,weights='imagenet',input_shape=(224,224,3));base.trainable=False
    @tf.function(input_signature=[tf.TensorSpec((None,224,224,3),tf.float32)])
    def encode(x):return pool(base(x,training=False))
    for study in studies:
        dest=args.cache/study;dest.mkdir(parents=True,exist_ok=True)
        rows,paths,y,split=dataset(args.data,args.manifests,study)
        identity=hashlib.sha256((args.manifests/f'{study}_split.csv').read_bytes()).hexdigest()
        for mode in ['corrected','legacy']:
            result=dest/f'{mode}.npz';meta=dest/f'{mode}.json'
            if result.exists() and meta.exists() and json.loads(meta.read_text())['split_sha256']==identity:continue
            vectors={k:[] for k in VARIANTS} if mode=='corrected' else {'legacy':[]}
            for first in range(0,len(paths),24):
                x=pixels(paths[first:first+24]);p=encode(x if mode=='corrected' else x/255.)
                for key in vectors:vectors[key].append(p['ap4' if key=='legacy' else key].numpy())
                if first%240==0 or first+len(x)==len(paths):print(study,mode,'encoded',first+len(x),'/',len(paths),flush=True)
            arrays={k:np.concatenate(v) for k,v in vectors.items()}
            np.savez_compressed(result,**arrays)
            save_json(meta,dict(split_sha256=identity,backbone_parameters=base.count_params(),inference_mode=True,range=[0,255] if mode=='corrected' else [0,1]))

def train(args,studies,protocol):
    for study in studies:
        rows,_,y,split=dataset(args.data,args.manifests,study);tr=split['train'];val=split['validation']
        setting=protocol['studies'][study]
        files={m:np.load(args.cache/study/f'{m}.npz') for m in ['corrected','legacy']}
        identity=hashlib.sha256((args.manifests/f'{study}_split.csv').read_bytes()).hexdigest()
        for variant in ['legacy',*VARIANTS]:
            features=files['legacy' if variant=='legacy' else 'corrected'][variant]
            for opt in OPTS:
                for seed in ([42] if variant=='legacy' else protocol['seeds']):
                    dest=args.output/study/variant/opt/str(seed);dest.mkdir(parents=True,exist_ok=True)
                    config=dict(protocol_sha256=args.protocol_sha,split_sha256=identity,study=study,variant=variant,optimizer=opt,seed=seed,**setting)
                    record=dest/'run.json'
                    if record.exists() and (dest/'head.keras').exists():
                        if json.loads(record.read_text())['config']==config:continue
                        raise ValueError('Existing run has different configuration: '+str(dest))
                    tf.keras.backend.clear_session();tf.keras.utils.set_random_seed(seed)
                    model=make_head(variant,seed);model.compile(optimizer=OPTS[opt](.001),loss='binary_crossentropy',metrics=['accuracy'])
                    options=tf.data.Options();options.threading.private_threadpool_size=1
                    ds=tf.data.Dataset.from_tensor_slices((features[tr],tf.keras.utils.to_categorical(y[tr],2))).shuffle(len(tr),seed=seed,reshuffle_each_iteration=True).batch(setting['batch_size']).with_options(options)
                    before=time.perf_counter();h=model.fit(ds,epochs=setting['epochs'],verbose=0);elapsed=time.perf_counter()-before
                    p=model(features[val],training=False).numpy();metrics=scores(y[val],p)
                    write_csv(dest/'validation_predictions.csv',prediction_rows([rows[i] for i in val],y[val],p))
                    write_csv(dest/'history.csv',[dict(epoch=i+1,**{k:float(v[i]) for k,v in h.history.items()}) for i in range(setting['epochs'])])
                    model.save(dest/'head.keras')
                    save_json(record,dict(config=config,validation=metrics,head_parameters=model.count_params(),updates=int(model.optimizer.iterations.numpy()),seconds=elapsed))
                    print('FIT',study,variant,opt,seed,'val F1',round(metrics['f1'],4),'seconds',round(elapsed,1),flush=True)

def selection(args,studies):
    selected={};recommended={};valrows=[]
    for study in studies:
        for variant in VARIANTS:
            summary={}
            for opt in OPTS:
                runs=[json.loads((args.output/study/variant/opt/str(seed)/'run.json').read_text()) for seed in [42,43,44]]
                summary[opt]={m:float(np.mean([r['validation'][m] for r in runs])) for m in ['f1','recall']}
                valrows.extend(dict(study=study,variant=variant,optimizer=opt,seed=r['config']['seed'],**r['validation']) for r in runs)
            best=sorted(OPTS,key=lambda o:(-summary[o]['f1'],-summary[o]['recall'],list(OPTS).index(o)))[0]
            selected[f'{study}:{variant}']=best
        ranks=[]
        for variant in VARIANTS:
            matching=[r for r in valrows if r['study']==study and r['variant']==variant and r['optimizer']==selected[f'{study}:{variant}']]
            head=make_head(variant,42)
            ranks.append((-np.mean([r['f1'] for r in matching]),-np.mean([r['recall'] for r in matching]),head.count_params(),VARIANTS.index(variant),variant))
        recommended[study]=sorted(ranks)[0][-1]
    write_csv(args.output/'validation_metrics.csv',valrows)
    save_json(args.output/'selection.json',dict(protocol_sha256=args.protocol_sha,optimizer=selected,recommended_variant=recommended,source='validation only; fixed rule in protocol.json'))
    return selected,recommended

def evaluate(args,studies):
    # Require all planned fits before opening new test predictions.
    expected=sum(3+len(VARIANTS)*3*3 for _ in studies)
    complete=[args.output/s/v/o/str(seed)/'run.json' for s in studies for v in ['legacy',*VARIANTS] for o in OPTS for seed in ([42] if v=='legacy' else [42,43,44])]
    assert len(complete)==expected and all(p.exists() for p in complete)
    selected,recommended=selection(args,studies);metrics=[]
    for study in studies:
        rows,_,y,split=dataset(args.data,args.manifests,study)
        files={m:np.load(args.cache/study/f'{m}.npz') for m in ['corrected','legacy']}
        for variant in ['legacy',*VARIANTS]:
            features=files['legacy' if variant=='legacy' else 'corrected'][variant]
            for opt in OPTS:
                for seed in ([42] if variant=='legacy' else [42,43,44]):
                    dest=args.output/study/variant/opt/str(seed)
                    model=tf.keras.models.load_model(dest/'head.keras',compile=False)
                    for splitname in ['train','test']:
                        ix=split[splitname];p=model(features[ix],training=False).numpy()
                        write_csv(dest/f'{splitname}_predictions.csv',prediction_rows([rows[i] for i in ix],y[ix],p))
                        metrics.append(dict(study=study,variant=variant,optimizer=opt,seed=seed,split=splitname,head_parameters=model.count_params(),**scores(y[ix],p)))
                    print('EVAL',study,variant,opt,seed,flush=True)
    write_csv(args.output/'metrics.csv',metrics)
    cross=[]
    if set(studies)=={'one','two','three'}:
        for source,target in [('one','three'),('three','one')]:
            rows,_,y,_=dataset(args.data,args.manifests,target);features=np.load(args.cache/target/'corrected.npz')
            for variant in ['ap4','spatial_pyramid']:
                opt=selected[f'{source}:{variant}']
                for seed in [42,43,44]:
                    model=tf.keras.models.load_model(args.output/source/variant/opt/str(seed)/'head.keras',compile=False)
                    p=model(features[variant],training=False).numpy()
                    write_csv(args.output/f'cross_domain/{source}_to_{target}/{variant}/{seed}_predictions.csv',prediction_rows(rows,y,p))
                    cross.append(dict(source=source,target=target,variant=variant,optimizer=opt,seed=seed,**scores(y,p)))
        write_csv(args.output/'cross_domain.csv',cross)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',type=Path,required=True)
    p.add_argument('--manifests',type=Path,default=HERE/'manifests');p.add_argument('--protocol',type=Path,default=HERE/'protocol.json')
    p.add_argument('--cache',type=Path,required=True);p.add_argument('--output',type=Path,default=HERE/'results')
    p.add_argument('--stage',choices=['cache','train','evaluate','all'],default='all');p.add_argument('--study',choices=['one','two','three','all'],default='all')
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True);a.protocol_sha=hashlib.sha256(a.protocol.read_bytes()).hexdigest()
    protocol=json.loads(a.protocol.read_text());studies=list(protocol['studies']) if a.study=='all' else [a.study]
    tf.config.experimental.enable_op_determinism();tf.keras.utils.set_random_seed(42)
    if a.stage in ['cache','all']:cache_features(a,studies)
    if a.stage in ['train','all']:train(a,studies,protocol)
    if a.stage in ['evaluate','all']:evaluate(a,studies)

if __name__=='__main__':main()
