"""Predict normal/defect for one image using an exported full B0 model."""
import argparse,json
import cv2,numpy as np,tensorflow as tf
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--model',required=True);p.add_argument('--image',required=True);a=p.parse_args()
    bgr=cv2.imread(a.image)
    if bgr is None:raise ValueError('Cannot decode image: '+a.image)
    rgb=cv2.resize(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB),(224,224)).astype(np.float32)
    model=tf.keras.models.load_model(a.model,compile=False);prob=model(rgb[None],training=False).numpy()[0]
    print(json.dumps(dict(image=a.image,p_normal=float(prob[0]),p_defect=float(prob[1]),prediction=['normal','defect'][int(prob.argmax())],input='RGB float32 0..255, OpenCV224 resize; no external division by255'),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
