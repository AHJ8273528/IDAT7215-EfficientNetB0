from pathlib import Path
import argparse,csv,json,hashlib
import numpy as np
from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score,matthews_corrcoef,cohen_kappa_score,roc_auc_score,average_precision_score,confusion_matrix
parser=argparse.ArgumentParser(description='Independently recompute all 459 rows in the supplied group project. No peer code is executed.')
parser.add_argument('--peer-root',type=Path,required=True)
parser.add_argument('--archive',type=Path)
parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'peer_evidence')
args=parser.parse_args();peer=args.peer_root;out=args.output;out.mkdir(parents=True,exist_ok=True)
def read(p):return list(csv.DictReader(p.open()))
reported=read(peer/'paper_results/all_metrics.csv');checks=[]
for r in reported:
 s,opt,variant,seed,split=(r[k] for k in ['study','optimizer','variant','seed','split'])
 if variant in ('reference','A'):
  root=peer/('results' if variant=='reference' else 'results_efficientnetv2m')/s
  file=root/opt/f'{split}_predictions.csv';manifest=read(root/'split.csv')
 else:
  root=peer/'innovation/results'/s
  file=root/variant/opt/seed/f'{split}_predictions.csv';manifest=read(root/'split.csv')
 expected={x['path']:int(x['class_id']) for x in manifest if x['split']==split}
 rows=read(file);assert len(rows)==len(expected)==len(set(x['path'] for x in rows))
 assert {x['path'] for x in rows}==set(expected)
 y=np.array([expected[x['path']]==0 for x in rows],int)
 original=variant in ('reference','A')
 p=np.array([[float(x[k]) for k in (['probability_0','probability_1'] if original else ['defect_probability','normal_probability'])] for x in rows])
 assert np.isfinite(p).all() and np.min(p)>=0 and np.max(p)<=1 and np.allclose(p.sum(1),1,atol=1e-5)
 pred=(p.argmax(1)==0).astype(int)
 for row,truth,hat in zip(rows,y,pred):
  if not original:assert int(row['true_class'])==1-truth and int(row['predicted_class'])==1-hat
  else:
   classmap={int(v['class_id']):v['label'] for v in manifest}
   assert row['label']==classmap[1-truth] and row['prediction']==classmap[1-hat]
 tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel()
 actual=dict(n=len(y),correct=int((y==pred).sum()),tp=int(tp),tn=int(tn),fp=int(fp),fn=int(fn),accuracy=accuracy_score(y,pred),precision=precision_score(y,pred,zero_division=0),recall=recall_score(y,pred,zero_division=0),f1=f1_score(y,pred,zero_division=0),mcc=matthews_corrcoef(y,pred),kappa=cohen_kappa_score(y,pred),auc=roc_auc_score(y,p[:,0]),map=(average_precision_score(y,p[:,0])+average_precision_score(1-y,p[:,1]))/2)
 for key,value in actual.items():np.testing.assert_allclose(value,float(r[key]),atol=1e-10,rtol=1e-10,err_msg=f'{file}: {key}')
 checks.append(dict(file=str(file.relative_to(peer)),**actual))
with (out/'recomputed_peer_metrics.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(checks[0]));w.writeheader();w.writerows(checks)
archive=args.archive
h=hashlib.sha256()
if archive:
 with archive.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
record=dict(archive=archive.name if archive else None,sha256=h.hexdigest() if archive else None,metric_rows_recomputed=len(checks),passed=True,method='Independent sklearn recomputation from supplied per-image probabilities and split manifests; teammate code not executed',scope='Arithmetic/provenance consistency only. This does not independently reproduce backbone inference or rule out omitted experiments.',preprocessing_observation='train.py load_images divides RGB by255 for InceptionResNetV2; official Keras preprocess_input maps raw0..255 to -1..1. This is a paper-style reproduction baseline, not a fully corrected Inception baseline.',shared_manifests_attribution='Relative paths and SHA256 hashes and split assignments adapted from user-supplied group archive; class ids reversed here so normal=0, defect=1. Peer evidence retains original defect=0.')
(out/'audit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
