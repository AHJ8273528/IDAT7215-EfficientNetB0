"""Audit exact duplicates and flag perceptually similar train/test photographs.

pHash is a similarity screen, not proof of common physical-object identity.
"""
import argparse,csv,hashlib,json
from collections import Counter,defaultdict
from pathlib import Path
import cv2,numpy as np
from prepare_data import local_path,sha

def read(p):return list(csv.DictReader(p.open()))
def write(p,rows):
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def phash(path):
    im=cv2.imread(str(path),cv2.IMREAD_GRAYSCALE)
    if im is None:raise ValueError(path)
    low=cv2.dct(cv2.resize(im,(32,32)).astype(np.float32))[:8,:8].flatten()
    bits=low>np.median(low[1:]);bits[0]=False
    return sum(int(b)<<i for i,b in enumerate(bits))
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',type=Path,required=True)
    p.add_argument('--manifests',type=Path,default=Path(__file__).resolve().parents[1]/'manifests')
    p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    assets=read(a.manifests/'assets_manifest.csv');reports=[];nearest=[]
    for study in ['one','two','three']:
        records=[r for r in assets if r['study']==study];split=read(a.manifests/f'{study}_split.csv')
        lookup={r['path']:r for r in split};hashgroups=defaultdict(list);values={}
        for r in records:
            path=local_path(a.data,r);actual=sha(path);assert actual==r['sha256']
            rel='/'.join(Path(r['path']).parts[2:]) if study in ['one','two'] else '/'.join(Path(r['path']).parts[1:])
            assert rel in lookup;hashgroups[actual].append(lookup[rel]['split']);values[rel]=phash(path)
        train=[r for r in split if r['split']=='train'];test=[r for r in split if r['split']=='test']
        hashes=np.array([values[r['path']] for r in train],np.uint64);suspicious=0
        for r in test:
            d=np.bitwise_count(np.bitwise_xor(hashes,np.uint64(values[r['path']]))).astype(int)
            index=int(d.argmin());suspicious+=int(d[index]<=4)
            nearest.append(dict(study=study,test_path=r['path'],nearest_train_path=train[index]['path'],phash_hamming=int(d[index]),test_label=int(r['class_id']),train_label=int(train[index]['class_id'])))
        reports.append(dict(study=study,n=len(records),sha256_all_verified=True,exact_duplicate_groups=sum(len(v)>1 for v in hashgroups.values()),exact_cross_split_groups=sum(len(set(v))>1 for v in hashgroups.values()),test_n=len(test),test_with_train_phash_distance_le4=suspicious,fraction_test_with_train_phash_distance_le4=suspicious/len(test)))
        print(reports[-1],flush=True)
    write(a.output/'data_audit.csv',reports);write(a.output/'nearest_train_phash.csv',nearest)
    (a.output/'data_audit_notes.json').write_text(json.dumps(dict(method='32x32 grayscale DCT, low8x8, 63 comparison bits (DC set0), nearest training image, fixed Hamming<=4 screen',interpretation='Similarity only. Camera/pose/background can make different objects similar; re-encoding and transformations can make same object dissimilar. No physical-object IDs are inferred.',study_two='Released pre-augmented data split at image level for reproduction. Original-image lineage unavailable; train/test independence cannot be established.',study_three='Filename sequences suggest related frames. No source video/print IDs are supplied, so randomized image splitting is not evidence of new-print generalization.'),indent=2)+'\n')
if __name__=='__main__':main()
