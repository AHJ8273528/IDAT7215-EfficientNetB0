"""Check pooling coverage and matched-control initialization independently of fits."""
import argparse,json
from pathlib import Path
import numpy as np,tensorflow as tf
from experiment import make_head,pool
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'models/model_structure_checks.json');a=p.parse_args()
    checked=[]
    for seed in [42,43,44]:
        b=make_head('gap_repeat',seed);c=make_head('spatial_pyramid',seed)
        assert b.count_params()==c.count_params()==409794
        for x,y in zip(b.get_weights(),c.get_weights()):np.testing.assert_array_equal(x,y)
        vector=np.random.default_rng(seed).normal(size=(2,1,1,1280)).astype(np.float32)
        maps=tf.constant(np.tile(vector,(1,7,7,1)));f=pool(maps)
        np.testing.assert_allclose(f['gap_repeat'],f['spatial_pyramid'],atol=2e-6,rtol=2e-6)
        np.testing.assert_allclose(b(f['gap_repeat'],training=False),c(f['spatial_pyramid'],training=False),atol=1e-5,rtol=1e-5)
        checked.append(seed)
    coverage={}
    for variant in ['ap4','gap_norm','spatial_pyramid']:
        maps=tf.Variable(tf.ones((1,7,7,1280)))
        with tf.GradientTape() as tape:value=tf.reduce_sum(pool(maps)[variant])
        derivative=tape.gradient(value,maps).numpy()[0,:,:,0];coverage[variant]=int((derivative!=0).sum())
    assert coverage=={'ap4':16,'gap_norm':49,'spatial_pyramid':49}
    record=dict(passed=True,matched_control_seeds=checked,spatial_and_repeat_identical_initial_weights=True,constant_spatial_feature_predictions_match=True,direct_pooling_position_coverage=coverage,scope='Direct aggregation of final feature cells only; receptive fields overlap, so AP4 is not an input-image crop.')
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
if __name__=='__main__':main()
