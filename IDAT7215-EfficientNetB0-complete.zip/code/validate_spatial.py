"""Matched random and capture-time validation of AP4 vs spatial pooling.

Five folds, seeds42/43/44, 50epochs, Adam0.001, batch30. The 223 active
images and fold class counts are identical between protocols. These are
within-session partitions inferred from EXIF, not physical-print groups.
"""
import argparse,json,time
from pathlib import Path
import numpy as np,tensorflow as tf
from experiment import read_csv,write_csv,save_json,make_head,scores,prediction_rows

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--cache',type=Path,required=True);a=p.parse_args();r=a.root
    out=r/'temporal_validation';out.mkdir(exist_ok=True)
    metadata={x['sample_id']:x for x in read_csv(r/'manifests/blocked_cv_manifest.csv')}
    random={x['sample_id']:int(x['random_fold']) for x in read_csv(r/'manifests/random_cv_assignments.csv')}
    rows=read_csv(r/'manifests/one_split.csv');y=np.array([int(x['class_id']) for x in rows])
    assert all(int(metadata[x['path']]['label'])==int(x['class_id']) for x in rows)
    active=np.array([int(metadata[x['path']]['use_in_block_cv'])==1 for x in rows])
    blocks=np.array([int(metadata[x['path']]['time_block']) for x in rows]);rb=np.array([random.get(x['path'],-1) for x in rows])
    assert active.sum()==223
    for k in range(5):
        for label in [0,1]:assert np.sum(active&(blocks==k)&(y==label))==np.sum(active&(rb==k)&(y==label))
    f=np.load(a.cache/'one/corrected.npz');metricrows=[];predrows=[]
    for protocol,b in [('random',rb),('blocked',blocks)]:
        for fold in range(5):
            test=np.flatnonzero(active&(b==fold));val=np.flatnonzero(active&(b==((fold+1)%5)))
            train=np.flatnonzero(active&~np.isin(b,[fold,(fold+1)%5]))
            for variant in ['ap4','spatial_pyramid']:
                x=f[variant]
                for seed in [42,43,44]:
                    dest=out/protocol/str(fold)/variant/str(seed);dest.mkdir(parents=True,exist_ok=True)
                    if (dest/'metrics.json').exists():
                        record=json.loads((dest/'metrics.json').read_text())
                    else:
                        tf.keras.backend.clear_session();tf.keras.utils.set_random_seed(seed)
                        model=make_head(variant,seed);model.compile(optimizer=tf.keras.optimizers.Adam(.001),loss='binary_crossentropy',metrics=['accuracy'])
                        opts=tf.data.Options();opts.threading.private_threadpool_size=1
                        ds=tf.data.Dataset.from_tensor_slices((x[train],tf.keras.utils.to_categorical(y[train],2))).shuffle(len(train),seed=seed,reshuffle_each_iteration=True).batch(30).with_options(opts)
                        before=time.perf_counter();h=model.fit(ds,epochs=50,verbose=0)
                        write_csv(dest/'history.csv',[dict(epoch=i+1,**{k:float(v[i]) for k,v in h.history.items()}) for i in range(50)])
                        record={}
                        for split,ix in [('validation',val),('test',test)]:
                            prob=model(x[ix],training=False).numpy();record[split]=scores(y[ix],prob)
                            write_csv(dest/f'{split}_predictions.csv',prediction_rows([rows[i] for i in ix],y[ix],prob))
                        record['seconds']=time.perf_counter()-before;save_json(dest/'metrics.json',record)
                    context=dict(protocol=protocol,fold=fold,variant=variant,seed=seed,n_train=len(train))
                    for split in ['validation','test']:
                        metricrows.append(dict(**context,split=split,**record[split]))
                        predrows.extend(dict(**context,split=split,**x) for x in read_csv(dest/f'{split}_predictions.csv'))
                    print('CV',protocol,fold,variant,seed,'test',record['test']['accuracy'],flush=True)
    write_csv(out/'metrics.csv',metricrows);write_csv(out/'predictions.csv',predrows)
    summary=[]
    for protocol in ['random','blocked']:
        for variant in ['ap4','spatial_pyramid']:
            folds=[];early=[];recalls=[]
            for fold in range(5):
                v=[x for x in metricrows if x['protocol']==protocol and x['variant']==variant and x['split']=='test' and x['fold']==fold]
                folds.append(np.mean([x['accuracy'] for x in v]));recalls.extend(x['recall'] for x in v)
                if fold==0:early=[x['accuracy'] for x in v]
            summary.append(dict(protocol=protocol,variant=variant,mean_fold_accuracy=float(np.mean(folds)),sd_of_five_fold_seed_means=float(np.std(folds,ddof=1)),mean_recall=float(np.mean(recalls)),fold0_accuracy=float(np.mean(early))))
    write_csv(out/'summary.csv',summary);save_json(out/'protocol.json',dict(fits=60,epochs=50,batch=30,seeds=[42,43,44],optimizer='Adam',learning_rate=.001,active_images=223,selection='Fixed recipes and final epoch; results descriptive and not used to change the three-Study model selection',scope='No physical-print IDs, no external-session test. Fold0 is earliest only for blocked protocol. Fold SD is descriptive, not a confidence interval.'))

if __name__=='__main__':
    tf.config.experimental.enable_op_determinism();main()
