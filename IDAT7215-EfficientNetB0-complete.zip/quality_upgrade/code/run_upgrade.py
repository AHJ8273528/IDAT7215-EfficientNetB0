"""Run the optional upgrade after the core three-Study package has completed."""
import argparse,os,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--data',type=Path,required=True);p.add_argument('--b0-cache',type=Path,required=True);p.add_argument('--cache',type=Path,required=True);p.add_argument('--keras-home',type=Path,required=True);a=p.parse_args()
    if not (a.root/'models/three_selected_seed42.keras').exists():raise ValueError('Complete core code/run_all.py first; its selected B0 model is required.')
    os.environ['KERAS_HOME']=str(a.keras_home.resolve());os.environ.setdefault('TF_NUM_INTRAOP_THREADS','4');os.environ.setdefault('TF_NUM_INTEROP_THREADS','2')
    dest=a.root/'quality_upgrade';dest.mkdir(exist_ok=True)
    if a.root.resolve()!=ROOT.resolve():
        shutil.copy2(ROOT/'quality_upgrade/protocol.json',dest/'protocol.json')
        shutil.copytree(ROOT/'quality_upgrade/code',dest/'code',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
        for name in ['README_previous_protocol.txt','report_section_v1.txt','speaking_script_v1.txt']:
            if (ROOT/name).exists():shutil.copy2(ROOT/name,a.root/name)
    def run(name,*args):subprocess.run([sys.executable,str(Path(__file__).parent/name),*map(str,args)],check=True)
    run('download_reference.py','--keras-home',a.keras_home)
    run('validate_gap.py','--root',a.root,'--cache',a.b0_cache)
    run('reference.py','--root',a.root,'--data',a.data,'--cache',a.cache)
    run('stress_tta.py','--root',a.root,'--data',a.data)
    run('quality_gate.py','--root',a.root,'--data',a.data)
    run('benchmark.py','--root',a.root,'--data',a.data,'--cache',a.cache)
    run('quality_verify.py','--root',a.root)
    run('summarize_upgrade.py','--root',a.root)
if __name__=='__main__':main()
