"""Optional domain-specific quality gate before loading the unchanged B0 classifier."""
import argparse,json
from pathlib import Path
import cv2,numpy as np
from quality_metric import quality
ROOT=Path(__file__).resolve().parents[2]
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--image',required=True);p.add_argument('--model',type=Path,default=ROOT/'models/three_selected_seed42.keras');p.add_argument('--calibration',type=Path,default=ROOT/'quality_upgrade/quality_gate/selection.json');a=p.parse_args()
    bgr=cv2.imread(a.image)
    if bgr is None:raise ValueError('Cannot decode image')
    rgb=cv2.resize(cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB),(224,224));cal=json.loads(a.calibration.read_text());value=quality(rgb)
    result=dict(image=a.image,quality_score=value,threshold=cal['threshold'],scope='Experimental StudyThree sharpness screen; other cameras/objects require new calibration.')
    if cal['adopt_gate'] and value<cal['threshold']:
        result.update(status='needs_retake',prediction=None,message='图片清晰度未达到本实验阈值，请重拍或人工复核。')
    else:
        import tensorflow as tf
        model=tf.keras.models.load_model(a.model,compile=False);prob=model(rgb[None].astype(np.float32),training=False).numpy()[0]
        result.update(status='classified',prediction=['normal','defect'][int(prob.argmax())],p_defect=float(prob[1]),message='已通过本实验清晰度筛查；不代表输入属于已验证的数据域。')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
