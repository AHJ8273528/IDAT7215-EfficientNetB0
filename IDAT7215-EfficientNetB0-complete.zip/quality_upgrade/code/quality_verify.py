"""Recompute upgrade metrics without TensorFlow (Python standard library only)."""
import argparse,json,sys,math,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'code'))
from verify import read,calculate,compare
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);a=p.parse_args();r=a.root;q=r/'quality_upgrade'
    metadata={x['sample_id']:x for x in read(r/'manifests/blocked_cv_manifest.csv')};active={k:v for k,v in metadata.items() if int(v['use_in_block_cv'])};random={x['sample_id']:int(x['random_fold']) for x in read(r/'manifests/random_cv_assignments.csv')}
    m=read(q/'gap_temporal_validation/metrics.csv');cvcount=0
    for row in m:
        b={k:(random[k] if row['protocol']=='random' else int(v['time_block'])) for k,v in active.items()};fold=int(row['fold']);target=fold if row['split']=='test' else (fold+1)%5
        expected={k:int(active[k]['label']) for k in active if b[k]==target}
        pred=q/f"gap_temporal_validation/{row['protocol']}/{fold}/gap_norm/{row['seed']}/{row['split']}_predictions.csv"
        compare(calculate(read(pred),expected),row);cvcount+=1
    assert cvcount==60
    manifest=read(r/'manifests/three_split.csv');groups={s:{x['path']:int(x['class_id']) for x in manifest if x['split']==s} for s in ['train','validation','test']}
    refmetrics=read(q/'corrected_inception/metrics.csv');refcount=0
    for row in refmetrics:
        dest=q/f"corrected_inception/{row['variant']}/{row['seed']}";pred=dest/f"{row['split']}_predictions.csv"
        compare(calculate(read(pred),groups[row['split']]),row);refcount+=1
        config=json.loads((dest/'run.json').read_text());assert config['updates']==1110 and config['config']['epochs']==30 and config['config']['batch_size']==30
    assert refcount==18
    selected=json.loads((q/'corrected_inception/selection.json').read_text())['variant']
    def rank(v):
        rows=[x for x in refmetrics if x['variant']==v and x['split']=='validation']
        return (-statistics.mean(float(x['f1']) for x in rows),-statistics.mean(float(x['recall']) for x in rows),['ap4','gap_norm'].index(v))
    assert selected==sorted(['ap4','gap_norm'],key=rank)[0]
    metrics=read(q/'stress/metrics.csv');pred=read(q/'stress/predictions.csv');views=read(q/'stress/per_view_predictions.csv');stresscount=0
    for row in metrics:
        match=[x for x in pred if all(x[k]==row[k] for k in ['split','condition','strategy'])]
        compare(calculate(match,groups[row['split']]),row);stresscount+=1
        view_lookup={(x['path'],x['view']):x for x in views if x['split']==row['split'] and x['condition']==row['condition']}
        for x in match:
            for col in ['normal_probability','defect_probability']:
                expected=float(view_lookup[x['path'],'original'][col])
                if row['strategy']=='mirror_tta':expected=(expected+float(view_lookup[x['path'],'mirror'][col]))/2
                assert math.isclose(float(x[col]),expected,abs_tol=1e-7,rel_tol=1e-6)
    assert stresscount==28 and len(pred)==len(views)==6552
    valid={}
    for strategy in ['single','mirror_tta']:
        a=[x for x in metrics if x['split']=='validation' and x['strategy']==strategy]
        valid[strategy]=dict(mean_f1=statistics.mean(float(x['f1']) for x in a),worst_recall=min(float(x['recall']) for x in a),clean_f1=float(next(x['f1'] for x in a if x['condition']=='clean')))
    b,c=valid['single'],valid['mirror_tta'];adopt=c['mean_f1']>=b['mean_f1']+.005 and c['clean_f1']>=b['clean_f1'] and c['worst_recall']>=b['worst_recall']
    assert adopt==json.loads((q/'stress/selection.json').read_text())['adopt_tta']
    gate=read(q/'quality_gate/predictions.csv');gaterecord=json.loads((q/'quality_gate/selection.json').read_text());threshold=gaterecord['threshold']
    clean=[x for x in gate if x['split']=='validation' and x['condition']=='clean']
    thresholds=[]
    for label in [0,1]:
        values=sorted(float(x['quality_score']) for x in clean if int(x['true_class'])==label);thresholds.append(values[int(.05*len(values))])
    assert threshold==min(thresholds)
    lookup={(x['split'],x['condition'],x['path']):x for x in pred if x['strategy']=='single'}
    for row in gate:
        assert int(row['accepted'])==int(float(row['quality_score'])>=threshold)
        other=lookup[row['split'],row['condition'],row['path']]
        assert row['true_class']==other['true_class'] and row['predicted_class']==other['predicted_class']
    for row in read(q/'quality_gate/metrics.csv'):
        matching=[x for x in gate if x['split']==row['split'] and (row['condition']=='ALL7' or x['condition']==row['condition'])]
        accepted=[x for x in matching if int(x['accepted'])];errors=sum(x['predicted_class']!=x['true_class'] for x in accepted)
        assert len(matching)==int(row['n']) and len(accepted)==int(row['accepted']) and errors==int(row['accepted_errors'])
        assert math.isclose(len(accepted)/len(matching),float(row['coverage']),abs_tol=1e-12)
        if accepted:assert math.isclose(errors/len(accepted),float(row['accepted_error_rate']),abs_tol=1e-12)
        else:assert row['accepted_error_rate']==''
    validation=[x for x in gate if x['split']=='validation'];accepted=[x for x in validation if int(x['accepted'])]
    baseerror=sum(x['predicted_class']!=x['true_class'] for x in validation)/len(validation);accepterror=sum(x['predicted_class']!=x['true_class'] for x in accepted)/len(accepted)
    retention=[statistics.mean(int(x['accepted']) for x in clean if int(x['true_class'])==label) for label in [0,1]]
    gateadopt=baseerror-accepterror>=.02 and len(accepted)/len(validation)>=.5 and min(retention)>=.95
    assert gateadopt==gaterecord['adopt_gate']
    timings=read(q/'benchmark/raw_timings.csv');summary=read(q/'benchmark/summary.csv');assert len(timings)==180
    for row in summary:
        times=[float(x['milliseconds']) for x in timings if x['model']==row['model']];assert len(times)==int(row['n'])==60 and min(times)>0
        assert math.isclose(statistics.median(times),float(row['median_ms']),abs_tol=1e-10)
    record=dict(passed=True,gap_cv_fits=30,gap_cv_metric_rows=cvcount,reference_fits=6,reference_metric_rows=refcount,stress_metric_rows=stresscount,stress_prediction_rows=len(pred),tta_probability_averaging_checked=True,tta_decision_recomputed_using_validation_only=True,reference_choice_recomputed_using_validation_only=True,quality_gate_rows=len(gate),quality_gate_threshold_and_validation_decision_recomputed=True,latency_samples=len(timings),scope='Integrity of saved predictions and measurements, not independent physical-print validation.')
    (q/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
if __name__=='__main__':main()
