"""Classical sharpness gate: abstain on low scores, report risk AND coverage."""
import argparse,json,math,sys
from pathlib import Path
import cv2,numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'code'))
from experiment import dataset,pixels,read_csv,write_csv,save_json
from stress_tta import transform,CONDITIONS
from quality_metric import quality
def summarize(rows):
    accepted=[x for x in rows if x['accepted']];errors=sum(x['true_class']!=x['predicted_class'] for x in accepted)
    totalerrors=sum(x['true_class']!=x['predicted_class'] for x in rows)
    return dict(n=len(rows),accepted=len(accepted),rejected=len(rows)-len(accepted),coverage=len(accepted)/len(rows),accepted_errors=errors,accepted_error_rate=errors/len(accepted) if accepted else None,baseline_errors=totalerrors,baseline_error_rate=totalerrors/len(rows),rejected_errors=totalerrors-errors)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',type=Path,required=True);p.add_argument('--root',type=Path,default=ROOT);a=p.parse_args();r=a.root;out=r/'quality_upgrade/quality_gate';out.mkdir(parents=True,exist_ok=True)
    manifest,paths,y,split=dataset(a.data,r/'manifests','three')
    valix=split['validation'];clean=pixels([paths[i] for i in valix]).astype(np.uint8);cleanquality=np.array([quality(im) for im in clean])
    thresholds=[float(np.sort(cleanquality[y[valix]==label])[int(.05*np.sum(y[valix]==label))]) for label in [0,1]]
    threshold=min(thresholds);records=[];metrics=[]
    for name in ['validation','test']:
        ix=split[name];images=clean if name=='validation' else pixels([paths[i] for i in ix]).astype(np.uint8)
        # Read known predictions only after fixing the threshold from clean validation scores.
        pred=read_csv(r/'quality_upgrade/stress/predictions.csv');pred={ (x['condition'],x['path']):x for x in pred if x['split']==name and x['strategy']=='single'}
        current=[]
        for condition in CONDITIONS:
            changed=transform(images,condition)
            for j,i in enumerate(ix):
                row=pred[condition,manifest[i]['path']];score=quality(changed[j])
                current.append(dict(split=name,condition=condition,path=manifest[i]['path'],true_class=int(row['true_class']),predicted_class=int(row['predicted_class']),quality_score=score,threshold=threshold,accepted=int(score>=threshold),defect_probability=float(row['defect_probability'])))
            metrics.append(dict(split=name,condition=condition,**summarize([x for x in current if x['condition']==condition])))
        metrics.append(dict(split=name,condition='ALL7',**summarize(current)));records.extend(current)
        if name=='validation':
            overall=metrics[-1];cleanrows=[x for x in current if x['condition']=='clean']
            retention={str(label):float(np.mean([x['accepted'] for x in cleanrows if x['true_class']==label])) for label in [0,1]}
            adopt=overall['accepted_error_rate'] is not None and overall['baseline_error_rate']-overall['accepted_error_rate']>=.02 and overall['coverage']>=.5 and min(retention.values())>=.95
            save_json(out/'selection.json',dict(threshold=threshold,per_class_order_statistics=thresholds,adopt_gate=adopt,clean_validation_retention=retention,validation_summary=overall,rule='Pooled validation error drops>=0.02, coverage>=0.5, clean retention>=0.95 for EACH class',inference_action='Retake a sharper image when score<threshold; never count rejected images as correct',scope='Exploratory synthetic-stress safety mechanism in this image domain; no guarantee for different cameras/objects. Prior test stress results already known.'))
    write_csv(out/'predictions.csv',records);write_csv(out/'metrics.csv',metrics)
    print((out/'selection.json').read_text())
if __name__=='__main__':main()
