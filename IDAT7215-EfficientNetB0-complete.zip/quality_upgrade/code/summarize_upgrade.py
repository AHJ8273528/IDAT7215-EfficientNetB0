"""Build upgrade findings, figures and report from saved evidence."""
import argparse,json,csv,statistics,shutil,re
from pathlib import Path
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[2]
def read(p):return list(csv.DictReader(p.open()))
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=ROOT);a=p.parse_args();r=a.root;q=r/'quality_upgrade'
    ref=read(q/'corrected_inception/metrics.csv');choice=json.loads((q/'corrected_inception/selection.json').read_text())['variant'];lat=read(q/'benchmark/summary.csv');gate=read(q/'quality_gate/metrics.csv')
    acc=lambda v:statistics.mean(float(x['accuracy']) for x in ref if x['split']=='test' and x['variant']==v)
    small=next(x for x in lat if x['model']=='B0 single');large=next(x for x in lat if x['model']=='Corrected Inception single');speed=float(large['median_ms'])/float(small['median_ms'])
    alltest=next(x for x in gate if x['split']=='test' and x['condition']=='ALL7');clean=next(x for x in gate if x['split']=='test' and x['condition']=='clean')
    summary=dict(reference_selected_head=choice,corrected_reference_accuracy=acc(choice),b0_accuracy=1.0,b0_parameters=int(small['total_parameters']),reference_parameters=int(large['total_parameters']),b0_median_ms=float(small['median_ms']),reference_median_ms=float(large['median_ms']),local_median_latency_ratio=speed,quality_gate_test_coverage=float(alltest['coverage']),quality_gate_test_accepted_error=float(alltest['accepted_error_rate']),always_classify_test_error=float(alltest['baseline_error_rate']),test_unique_images=309,test_transformed_versions=2163,clean_test_acceptance=float(clean['coverage']),tta_adopted=False)
    (q/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(11,4.8));x=np.arange(3)
    vals=[acc('ap4')*100,acc('gap_norm')*100,100];sd=[statistics.stdev(float(z['accuracy'])*100 for z in ref if z['split']=='test' and z['variant']==v) for v in ['ap4','gap_norm']]+[0]
    axes[0].bar(x,vals,color=['#9ba9b5','#7e9b96','#24786e'],yerr=sd,capsize=4);axes[0].set_xticks(x,['Inception\nAP4','Inception\nGAP + norm','B0\nGAP + norm']);axes[0].set_ylim(0,108);axes[0].set_ylabel('Test accuracy (%)');axes[0].set_title('Corrected input; 3-seed mean ± SD')
    for i,v in enumerate(vals):axes[0].text(i,v+2,f'{v:.2f}%',ha='center')
    axes[1].bar(['B0','Corrected\nInception'],[float(small['median_ms']),float(large['median_ms'])],color=['#24786e','#9ba9b5']);axes[1].set_ylabel('Median milliseconds per image');axes[1].set_title('Same CPU, serial interleaved timing')
    for i,v in enumerate([float(small['median_ms']),float(large['median_ms'])]):axes[1].text(i,v+1,f'{v:.2f} ms',ha='center')
    fig.suptitle('Study Three: matched split, runtime, optimizer and30-epoch budget');fig.tight_layout();fig.savefig(q/'corrected_reference_comparison.png',dpi=180);plt.close(fig)
    conditions=['clean','brightness0.5','brightness1.5','blur9_sigma2.0','jpeg_quality15','resize56','rotate10_reflect'];data=[next(z for z in gate if z['split']=='test' and z['condition']==c) for c in conditions]
    names=['Clean','Dark','Bright','Blur','JPEG15','Resize56','Rotate10'];fig,axes=plt.subplots(1,2,figsize=(13,4.8));x=np.arange(7)
    axes[0].bar(x,[100*float(z['coverage']) for z in data],color='#24786e');axes[0].set_ylim(0,105);axes[0].set_ylabel('Accepted inputs (%)');axes[0].set_title('Coverage: no forced decision below threshold');axes[0].set_xticks(x,names,rotation=20)
    b=[100*float(z['baseline_error_rate']) for z in data];c=[100*float(z['accepted_error_rate']) if z['accepted_error_rate'] else np.nan for z in data]
    axes[1].bar(x-.18,b,.36,label='Always classify',color='#9ba9b5');axes[1].bar(x+.18,c,.36,label='Accepted only',color='#24786e');axes[1].set_xticks(x,names,rotation=20);axes[1].set_ylabel('Error rate (%)');axes[1].set_title('Risk must be read together with coverage');axes[1].legend()
    for i,v in enumerate(c):
        if not np.isfinite(v):axes[1].text(i,.5,'No\ndecisions',ha='center',fontsize=8)
    fig.suptitle('309 known images ×7 conditions; rejected images are not counted correct');fig.tight_layout();fig.savefig(q/'quality_gate_tradeoff.png',dpi=180);plt.close(fig)
    notes=f'''本轮增强版（v2）：正确基线、真实耗时、清晰度拒判原型

现在更扎实的结论
1. 补做官方正确[-1,1]预处理的InceptionResNetV2，和B0处于同一个TensorFlow/Keras环境。两种Inception头×3种子，共6次新训练；同一个StudyThree1557张名单、1089/159/309划分、Adam0.001、30轮、批30、冻结主干。
   Inception AP4平均{100*acc('ap4'):.2f}%；GAP+固定归一化平均{100*acc('gap_norm'):.2f}%；验证集选出{choice}。B0 GAP+norm三种子均100%。这里的优势为{100*(1-acc(choice)):.2f}个百分点；不能继续只用对方原始97.09%作为唯一比较。
2. 同CPU、同20张图、各模型60次计时（5次预热，随机交错执行）：B0中位数{float(small['median_ms']):.2f}ms，正确预处理Inception为{float(large['median_ms']):.2f}ms，局部中位延迟比{speed:.2f}倍。输入224、单张，计入CNN和分类头、不计读文件和缩放。这是本机微基准，不保证别的设备也有相同比率。参数4,131,685对54,435,234，少92.41%。
3. 补齐GAP头在StudyOne圆柱数据上的30次随机／时间重训。随机平均99.45%，时间块94.69%，时间块缺陷召回89.60%；早期块73.47%。AP4对应时间准确率95.65%、Recall97.87%。这是头结构在圆柱域逐折重训的比较，不是把已训练的StudyThree模型拿到新工件外测。主模型的测试满分仍有条件。
4. 两视角镜像平均未通过验证集预定规则：七种条件验证平均F1由0.9262降到0.9037，最差Recall0.5769降到0.5000。因此仍用单视角；不根据测试结果倒选增强方式。

新增的可演示功能：图片太模糊时请求重拍
质量分数采用224灰度Laplacian方差／平均亮度平方。只用干净验证集确定阈值0.2450452563，并在验证集按预定规则检查是否值得启用。没有新增CNN参数；增加一个验证集确定的阈值。低分输入返回needs_retake，既不输出缺陷类别，也不算识别正确。
测试探针：309张原测试图的7个条件，共2163个图像版本，并非2163个独立原图。始终分类错160/2163，错误率7.40%。质量门接受1166/2163（53.91%覆盖），其中错20/1166（1.72%接受样本错误率），其余997次要求重拍。干净图接受287/309（92.88%），22张干净图也被拒绝。模糊、低分辨率和旋转条件全部被拒；JPEG错误没有得到解决。质量门牺牲覆盖率，不能称全部输入准确率提高到98.28%。这是一项有明显成本的研究原型，不能直接作为实际工厂部署保证。
扩展设计发生在先前压力测试已知之后，尽管阈值与启用规则只用验证集，这仍是探索性评估，不是全新盲测。不同背景、相机或物体需要重新校准和独立外测。

如何用
查看全部现成证据：quality_upgrade/summary.json、corrected_inception/metrics.csv、benchmark/raw_timings.csv、stress/metrics.csv、quality_gate/metrics.csv、gap_temporal_validation/summary.csv。
    python main.py --verify
普通原始推理仍为根目录code/predict.py。可选质量检查演示：
    python quality_upgrade/code/predict_checked.py --image YOUR_IMAGE.jpg
主模型不变，输入仍是RGB0–255。拒判时程序在加载TensorFlow模型前返回，便于演示流程。

重跑扩展（先完成根目录code/run_all.py，数据/特征路径按实际填写）
    python quality_upgrade/code/run_upgrade.py --data work/data --b0-cache work/features --cache work/reference_features --keras-home work/keras_cache
官方参考权重约209MiB，下载后校验MD5；不放入ZIP。特征缓存也不交付，程序会重建。新输出目录可用--root指向已完成核心实验的rerun/。Notebook新增可选扩展单元，本机已执行所有实验程序，Notebook未在远程Colab重跑。

报告与PPT
根目录report_section.txt和speaking_script.txt更新为本轮证据。EfficientNetB0_presentation_v2_final.pptx为新版两页，图表可编辑；页脚还需真实演讲者姓名。旧版保留作记录，不要混用旧速度和新速度结果。
本轮共新增36次训练；连同原117次主训练和60次时间实验，累计213次。quality_upgrade/verification.json用独立标准库程序复算新指标、概率平均、阈值和耗时。报告应如实注明助手支持与既有方法来源。

方法来源
Keras官方Inception预处理：https://keras.io/api/applications/inceptionresnetv2/inception_resnet_v2_preprocessing/
OpenCV Laplacian算子：https://docs.opencv.org/4.x/d5/db5/tutorial_laplace_operator.html
亮度归一化分数、阈值和启用规则为本项目的工程选择，不声称OpenCV官方推荐这套拒判标准或全局首创。
'''
    (q/'README.txt').write_text(notes)
    if (r/'START_HERE.txt').exists() and not (r/'README_previous_protocol.txt').exists():shutil.copy2(r/'START_HERE.txt',r/'README_previous_protocol.txt')
    (r/'START_HERE.txt').write_text('先读 quality_upgrade/README.txt：这是v2最新结论与操作说明。\n新版PPT：EfficientNetB0_presentation_v2_final.pptx。主报告：report_section.txt。\n完整包包含模型；review包不含.keras，仍可离线核验所有预测。\npython main.py --verify\n\n三个Study原完整清单和训练设置见README_previous_protocol.txt；本轮主要补强StudyThree公平对照、同机速度、GAP在StudyOne的时间重训，以及可选图片质量筛查。\n累计213次训练；所有测试均来自已知公开图像，未建立全新打印件盲测。\n')
    for name in ['report_section.txt','speaking_script.txt']:
        if (r/name).exists() and not (r/(name.removesuffix('.txt')+'_v1.txt')).exists():shutil.copy2(r/name,r/(name.removesuffix('.txt')+'_v1.txt'))
    report=f'''EfficientNetB0: controlled reference comparison and selective prediction

Our EfficientNetB0 experiments used the group’s shared original, augmented and Kaggle inventories [3]–[5], containing271,3017 and1557 images. All4845 files matched the shared SHA-256 manifest. The three training/validation/test sizes were189/27/55,2111/308/598 and1089/159/309. Frozen ImageNet features,224-by-224 RGB inputs, binary cross-entropy and fixed final-epoch evaluation supported reproducibility. Four corrected heads, three optimizers and seeds42–44, plus nine legacy-input controls, produced117 main fits. The selected B0 accuracies were99.39%,99.83% and100% in Studies One,Two andThree.

We strengthened the StudyThree comparison by independently retraining InceptionResNetV2 with its official preprocessing, mapping raw pixels to[-1,1] [1]. This controlled the preprocessing mismatch and software-version confounds in the supplied peer comparison. Both backbones used Adam0.001,30epochs,batch30, identical image partitions and three seeds. Inception’s reference pooling and normalized global-pooling heads averaged{100*acc('ap4'):.2f}% and{100*acc('gap_norm'):.2f}% test accuracy. Validation F1 selected normalized global pooling for both architectures. B0 achieved309/309 correct classifications, including all153 defects, in every seed. Its100% mean exceeded the selected corrected reference by{100*(1-acc(choice)):.2f}percentage points. These seeds reuse the same309 test images and do not constitute independent datasets or establish statistical significance.

B0 contained4,131,685 parameters versus54,435,234 for Inception, reducing parameter count by92.41%. A serial, interleaved microbenchmark used the same20 images, five warmups and60 measurements per strategy on the same CPU. Median inference latency was{float(small['median_ms']):.2f}ms for B0 and{float(large['median_ms']):.2f}ms for corrected Inception, a{speed:.2f}-fold local median-latency ratio. Timing included preprocessing within the network and classification, but excluded file decoding and resizing. Other devices may give different ratios.

Seven predefined image conditions exposed robustness limitations. Mirror-averaged inference failed its validation adoption rule and was not recommended. We then explored a brightness-normalized Laplacian-variance quality screen using the OpenCV operator [2]. Its threshold used only clean validation images; a fixed validation rule required lower accepted-sample error, at least50% overall coverage and at least95% clean retention in each class. Inputs below the threshold requested a sharper image instead of receiving a forced class.

On2163 transformed test versions of309 known images, always classifying produced160 errors(7.40%). The screen accepted1166 versions(53.91%coverage), with20 errors(1.72%accepted error);997 were rejected. Clean-image acceptance was92.88%, and compressed-image errors remained. Rejections are not counted as correct predictions. This exploratory extension followed earlier stress testing and is not a fresh blind evaluation.

An additional30 fits assessed the normalized GAP head on StudyOne temporal partitions: random-fold accuracy was99.45%, while time-block accuracy was94.69% and defect recall89.60%. These are within-session retraining results, not external tests of the deployed StudyThree weights. Related frames, absent physical-print IDs and poor cross-dataset results limit claims about new printers or objects. Further independent acquisition and recalibration are necessary before deployment.

References
[1] Keras, “InceptionResNetV2 preprocessing utilities.” https://keras.io/api/applications/inceptionresnetv2/inception_resnet_v2_preprocessing/. Accessed Nov.23,2026.
[2] OpenCV, “Laplace Operator.” https://docs.opencv.org/4.x/d5/db5/tutorial_laplace_operator.html. Accessed Nov.23,2026.
[3] M. M. Ahsan et al., “Defect analysis of 3D printed object using transfer learning approaches,” Expert Systems with Applications, vol.253, art.124293,2024, doi:10.1016/j.eswa.2024.124293.
[4] M. Ahsan, “AMdataset,” GitHub, commit52fe75dec70c1e8046493b4e3256f8f752a4d39d. https://github.com/mahsan2/AMdataset/tree/52fe75dec70c1e8046493b4e3256f8f752a4d39d.
[5] Justin900429, “3D-Printer Defected Dataset,” Kaggle,version1. https://www.kaggle.com/datasets/justin900429/3d-printer-defected-dataset.
[6] Keras, “EfficientNet models.” https://keras.io/api/applications/efficientnet/efficientnet_models/.
Adapt reference numbering to the full group report.
Attribution: group-provided manifests and peer predictions are explicitly credited. Implementation, execution, verification and draft writing were assistant-supported. The quality score and adoption policy are engineering choices, not claimed as a globally novel invention.
'''
    def polish(text):
        tokens={'EfficientNetB0':'MODELBO','InceptionResNetV2':'MODELIR','B0':'MODELSMALL','F1':'METRICFONE'}
        for original,temp in tokens.items():text=text.replace(original,temp)
        text=re.sub(r'([A-Za-z])(\d)',r'\1 \2',text)
        text=re.sub(r'(\d)([A-Za-z])',r'\1 \2',text)
        text=re.sub(r'%([A-Za-z])',r'% \1',text)
        text=re.sub(r'([A-Za-z0-9%])\(',r'\1 (',text)
        text=re.sub(r'([,;])(?=[A-Za-z])',r'\1 ',text)
        for original,temp in tokens.items():text=text.replace(temp,original)
        text=text.replace('containing 271,3017 and 1557','containing 271, 3,017 and 1,557').replace('All 4845','All 4,845').replace('189/27/55,2111/308/598','189/27/55, 2,111/308/598').replace('and 1089/159/309','and 1,089/159/309').replace('features,224','features, 224').replace('99.39%,99.83%','99.39%, 99.83%').replace('Adam 0.001,30','Adam 0.001, 30').replace('to[-1,1]','to [-1,1]').replace('error);997','error); 997').replace('andThree','and Three')
        return text.replace('StudyThree','Study Three').replace('StudyOne','Study One').replace('One,Two andThree','One, Two and Three')
    body,refs=report.split('References',1);report=polish(body)+'References'+refs
    (r/'report_section.txt').write_text(report)
    speech=f'''Two-slide script, approximately110seconds

Slide1
I strengthened our comparison by retraining Inception-ResNet with its official input preprocessing in the same runtime as EfficientNetB0. Both used the same StudyThree images, partitions,Adam optimizer and thirty epochs, with three training seeds. Validation selected normalized global pooling for both. The corrected Inception model averaged99.57 percent accuracy; B0 reached100 percent, detecting all153 defects in each seed. B0 also used4.13 million parameters versus54.44 million. On the same CPU, median single-image latency was{float(small['median_ms']):.2f} versus{float(large['median_ms']):.2f}milliseconds. This is a local benchmark, and the three seeds reuse the same test images.

Slide2
Clean test accuracy did not guarantee robustness. Under seven image conditions, forced classification produced7.40 percent error. Mirror averaging did not pass the validation rule. I therefore explored a simple sharpness check, calibrated on clean validation images, that requests a clearer image when its score is low. In the test probe it accepted53.91 percent of inputs, with1.72 percent error among accepted inputs. The tradeoff is substantial: nearly half required review, and7.12 percent of clean images were also rejected. Compression errors remained. These are transformed versions of309 known images, not a new factory test. The value is an explicit risk-versus-coverage experiment, with an honest request-to-retake option rather than silently treating rejected images as correct.

中文理解与问答
本轮主要增强是更严格的Inception对照、同机推理计时，以及可演示的清晰度不足时重拍机制；CNN没有继续变大。
不能把7.40%→1.72%写成同分母的总体错误率下降：前者2163个输入，后者1166个接受输入；拒判997个不是正确997个。
每个条件只有309张原图的一个版本，合计2163个版本并非2163个独立样本。
时间块94.69%来自StudyOne上GAP头的逐折重训，不是StudyThree模型对全新工件的外部测试。
为什么清晰图也被拒？简单清晰度指标与物体纹理、拍摄条件相关，阈值会带来误拒；本次干净图误拒22/309，必须报告。
为什么不推荐镜像平均？验证F1和最差召回下降，增加计算成本也没有通过采用条件。
更新PPT后仍需在每页页脚补你的真实姓名。个人贡献应按实际理解、修改和复核情况如实填写。
'''
    english,chinese=speech.split('中文理解与问答',1);speech=polish(english)+'中文理解与问答'+chinese
    (r/'speaking_script.txt').write_text(speech)
    print(json.dumps(summary,indent=2));print('Report words',len(report.split('References')[0].split()))
if __name__=='__main__':main()
