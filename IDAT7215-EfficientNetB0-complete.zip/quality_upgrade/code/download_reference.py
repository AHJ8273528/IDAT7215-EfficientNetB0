"""Fetch official InceptionResNetV2 ImageNet no-top weights with MD5 check."""
import argparse,hashlib,urllib.request,shutil
from pathlib import Path
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--keras-home',type=Path,required=True);a=p.parse_args()
    name='inception_resnet_v2_weights_tf_dim_ordering_tf_kernels_notop.h5';expected='d19885ff4a710c122648d3b5c3b684e4'
    dest=a.keras_home/'models'/name;dest.parent.mkdir(parents=True,exist_ok=True)
    digest=lambda p:hashlib.md5(p.read_bytes()).hexdigest()
    if dest.exists() and digest(dest)==expected:print('Official weights already verified');return
    tmp=dest.with_suffix('.download.part')
    with urllib.request.urlopen('https://storage.googleapis.com/tensorflow/keras-applications/inception_resnet_v2/'+name,timeout=120) as src,tmp.open('wb') as dst:shutil.copyfileobj(src,dst)
    assert digest(tmp)==expected;tmp.replace(dest);print('Official reference weights verified',dest.stat().st_size,flush=True)
if __name__=='__main__':main()
