"""Fixed, brightness-normalized Laplacian-variance score at224x224 RGB."""
import cv2,numpy as np
def quality(image):
    gray=cv2.cvtColor(image.astype(np.uint8),cv2.COLOR_RGB2GRAY)
    return float(cv2.Laplacian(gray,cv2.CV_64F,ksize=3).var()/max(float(gray.mean())**2,1.0))
