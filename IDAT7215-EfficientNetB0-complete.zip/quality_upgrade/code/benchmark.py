"""Same-machine timing and direct/cached probability checks of selected models."""
import argparse,json,os,sys,time
from pathlib import Path
import numpy as np,tensorflow as tf
from reference import encoder,ROOT
sys.path.insert(0,str(ROOT/'code'))
from experiment import dataset,pixels,read_csv,write_csv,save_json
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',required=True,type=Path);p.add_argument('--cache',required=True,type=Path);p.add_argument('--root',type=Path,default=ROOT)
    p.add_argument('--weights',type=Path,default=Path(os.environ.get('KERAS_HOME',str(Path.home()/'.keras')))/'models/inception_resnet_v2_weights_tf_dim_ordering_tf_kernels_notop.h5')
    a=p.parse_args();r=a.root;out=r/'quality_upgrade/benchmark';out.mkdir(parents=True,exist_ok=True)
    rows,paths,y,splits=dataset(a.data,r/'manifests','three');ix=splits['test'][:20];images=pixels([paths[i] for i in ix])
    b0=tf.keras.models.load_model(r/'models/three_selected_seed42.keras',compile=False)
    selected=json.loads((r/'quality_upgrade/corrected_inception/selection.json').read_text())['variant']
    enc,params=encoder(a.weights);head=tf.keras.models.load_model(r/f'quality_upgrade/corrected_inception/{selected}/42/head.keras',compile=False)
    raw=tf.keras.Input((224,224,3));ref=tf.keras.Model(raw,head(enc(raw,training=False)[selected],training=False))
    expected=read_csv(r/f'quality_upgrade/corrected_inception/{selected}/42/test_predictions.csv')
    expected={v['path']:float(v['defect_probability']) for v in expected};reference_probs=ref(images[:3],training=False).numpy()[:,1]
    np.testing.assert_allclose(reference_probs,[expected[rows[i]['path']] for i in ix[:3]],atol=1e-5,rtol=1e-5)
    official=tf.keras.applications.inception_resnet_v2.preprocess_input(images[:1].copy())
    layer=tf.keras.layers.Rescaling(1/127.5,offset=-1)(images[:1]).numpy();np.testing.assert_allclose(official,layer,atol=2e-7,rtol=2e-7)
    @tf.function(input_signature=[tf.TensorSpec((1,224,224,3),tf.float32)])
    def small(x):return b0(x,training=False)
    @tf.function(input_signature=[tf.TensorSpec((1,224,224,3),tf.float32)])
    def large(x):return ref(x,training=False)
    @tf.function(input_signature=[tf.TensorSpec((1,224,224,3),tf.float32)])
    def tta(x):return tf.reduce_mean(b0(tf.concat([x,tf.reverse(x,axis=[2])],axis=0),training=False),axis=0,keepdims=True)
    functions={'B0 single':small,'Corrected Inception single':large,'B0 mirror TTA':tta}
    for function in functions.values():
        for _ in range(5):function(images[:1]).numpy()
    rawrows=[];rng=np.random.default_rng(2026)
    for repeat in range(3):
        for i,image in enumerate(images):
            for name in rng.permutation(list(functions)):
                before=time.perf_counter();functions[name](image[None]).numpy();elapsed=(time.perf_counter()-before)*1000
                rawrows.append(dict(model=name,repeat=repeat,path=rows[ix[i]]['path'],milliseconds=elapsed))
    write_csv(out/'raw_timings.csv',rawrows);summary=[]
    for name in functions:
        v=[x['milliseconds'] for x in rawrows if x['model']==name]
        summary.append(dict(model=name,n=len(v),median_ms=float(np.median(v)),p10_ms=float(np.percentile(v,10)),p90_ms=float(np.percentile(v,90)),mean_ms=float(np.mean(v)),total_parameters=ref.count_params() if name.startswith('Corrected') else b0.count_params()))
    write_csv(out/'summary.csv',summary)
    save_json(out/'context.json',dict(seed42=True,reference_head=selected,images=20,repeats_per_image=3,warmups_per_graph=5,input_batch_size=1,order='Interleaved models in fixed RNG2026 random order per image',device='Same Apple Silicon CPU, TF intraop4/inter2; no GPU',excludes='File decoding, resize, model loading, graph tracing',includes='CNN and classifier; mirror concatenation and averaging for TTA',reference_direct_vs_cached_max_error=float(np.max(np.abs(reference_probs-np.array([expected[rows[i]['path']] for i in ix[:3]])))),official_preprocessing_equivalence=True,scope='Small local microbenchmark, not a general device-independent latency guarantee.'))
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
