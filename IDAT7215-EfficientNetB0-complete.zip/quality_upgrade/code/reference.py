"""Corrected InceptionResNetV2 reference in the same runtime and StudyThree split."""
import argparse,hashlib,json,os,sys,time
from pathlib import Path
import numpy as np,tensorflow as tf
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'code'))
from experiment import dataset,pixels,read_csv,write_csv,save_json,scores,prediction_rows

def encoder(weights):
    base=tf.keras.applications.InceptionResNetV2(include_top=False,weights=str(weights),input_shape=(224,224,3));base.trainable=False
    raw=tf.keras.Input((224,224,3),name='raw_rgb_0_255')
    x=tf.keras.layers.Rescaling(1/127.5,offset=-1,name='official_inception_preprocessing')(raw)
    maps=base(x,training=False);assert tuple(maps.shape[1:])==(5,5,1536)
    outputs={'ap4':tf.keras.layers.Flatten()(tf.keras.layers.AveragePooling2D(4)(maps)),
             'gap_norm':tf.keras.layers.GlobalAveragePooling2D()(maps)}
    return tf.keras.Model(raw,outputs,name='corrected_inception_encoder'),base.count_params()

def head(variant,seed):
    x=tf.keras.Input((1536,));h=x
    if variant=='gap_norm':h=tf.keras.layers.LayerNormalization(center=False,scale=False,epsilon=1e-5)(h)
    h=tf.keras.layers.Dense(64,activation='relu',kernel_initializer=tf.keras.initializers.GlorotUniform(seed),name='hidden')(h)
    h=tf.keras.layers.Dropout(.5,seed=seed)(h)
    z=tf.keras.layers.Dense(2,kernel_initializer=tf.keras.initializers.GlorotUniform(seed+1000),name='logits')(h)
    return tf.keras.Model(x,tf.keras.layers.Softmax()(z))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',required=True,type=Path);p.add_argument('--cache',required=True,type=Path)
    p.add_argument('--root',type=Path,default=ROOT);p.add_argument('--stage',choices=['cache','train','evaluate','all'],default='all')
    p.add_argument('--weights',type=Path,default=Path(os.environ.get('KERAS_HOME',str(Path.home()/'.keras')))/'models/inception_resnet_v2_weights_tf_dim_ordering_tf_kernels_notop.h5')
    a=p.parse_args();out=a.root/'quality_upgrade/corrected_inception';out.mkdir(parents=True,exist_ok=True);a.cache.mkdir(parents=True,exist_ok=True)
    rows,paths,y,split=dataset(a.data,a.root/'manifests','three');tr=split['train'];val=split['validation']
    identity=hashlib.sha256((a.root/'manifests/three_split.csv').read_bytes()).hexdigest()
    features=a.cache/'inception_corrected.npz';meta=a.cache/'inception_corrected.json'
    if a.stage in ['cache','all']:
        if not (features.exists() and meta.exists() and json.loads(meta.read_text())['split_sha256']==identity):
            assert a.weights.exists(),'Run download_reference.py first'
            assert hashlib.md5(a.weights.read_bytes()).hexdigest()=='d19885ff4a710c122648d3b5c3b684e4'
            enc,params=encoder(a.weights)
            @tf.function(input_signature=[tf.TensorSpec((None,224,224,3),tf.float32)])
            def encode(x):return enc(x,training=False)
            values={'ap4':[],'gap_norm':[]}
            for first in range(0,len(rows),12):
                x=pixels(paths[first:first+12]);v=encode(x)
                for key in values:values[key].append(v[key].numpy())
                if first%120==0 or first+len(x)==len(rows):print('Reference encoded',first+len(x),'/',len(rows),flush=True)
            np.savez_compressed(features,**{key:np.concatenate(v) for key,v in values.items()})
            save_json(meta,dict(split_sha256=identity,backbone_parameters=params,input='raw0..255 internally Rescaling(1/127.5,-1)',official_weights_md5='d19885ff4a710c122648d3b5c3b684e4',feature_shape=[5,5,1536]))
            del enc;tf.keras.backend.clear_session()
    save_json(out/'feature_protocol.json',json.loads(meta.read_text()))
    f=np.load(features);backbone=json.loads(meta.read_text())['backbone_parameters']
    if a.stage in ['train','all']:
        for variant in ['ap4','gap_norm']:
            x=f[variant]
            for seed in [42,43,44]:
                dest=out/variant/str(seed);dest.mkdir(parents=True,exist_ok=True)
                config=dict(variant=variant,seed=seed,epochs=30,batch_size=30,learning_rate=.001,optimizer='Adam',split_sha256=identity,preprocessing='official -1..1')
                if (dest/'run.json').exists():
                    assert json.loads((dest/'run.json').read_text())['config']==config;continue
                tf.keras.backend.clear_session();tf.keras.utils.set_random_seed(seed);model=head(variant,seed)
                model.compile(optimizer=tf.keras.optimizers.Adam(.001),loss='binary_crossentropy',metrics=['accuracy'])
                options=tf.data.Options();options.threading.private_threadpool_size=1
                ds=tf.data.Dataset.from_tensor_slices((x[tr],tf.keras.utils.to_categorical(y[tr],2))).shuffle(len(tr),seed=seed,reshuffle_each_iteration=True).batch(30).with_options(options)
                start=time.perf_counter();h=model.fit(ds,epochs=30,verbose=0);elapsed=time.perf_counter()-start
                prob=model(x[val],training=False).numpy();model.save(dest/'head.keras')
                write_csv(dest/'validation_predictions.csv',prediction_rows([rows[i] for i in val],y[val],prob))
                write_csv(dest/'history.csv',[dict(epoch=i+1,**{k:float(v[i]) for k,v in h.history.items()}) for i in range(30)])
                save_json(dest/'run.json',dict(config=config,validation=scores(y[val],prob),head_parameters=model.count_params(),backbone_parameters=backbone,updates=int(model.optimizer.iterations.numpy()),seconds=elapsed))
                print('Reference FIT',variant,seed,flush=True)
    if a.stage in ['evaluate','all']:
        runs={(v,s):json.loads((out/v/str(s)/'run.json').read_text()) for v in ['ap4','gap_norm'] for s in [42,43,44]}
        def rank(v):
            return (-np.mean([runs[v,s]['validation']['f1'] for s in [42,43,44]]),-np.mean([runs[v,s]['validation']['recall'] for s in [42,43,44]]),['ap4','gap_norm'].index(v))
        choice=sorted(['ap4','gap_norm'],key=rank)[0]
        save_json(out/'selection.json',dict(variant=choice,optimizer='Adam',selection='3-seed mean validation F1, recall, fixed AP4 tie-break. No test scores used.'))
        metrics=[]
        for variant in ['ap4','gap_norm']:
            for seed in [42,43,44]:
                dest=out/variant/str(seed);model=tf.keras.models.load_model(dest/'head.keras',compile=False)
                for name,ix in split.items():
                    prob=model(f[variant][ix],training=False).numpy()
                    write_csv(dest/f'{name}_predictions.csv',prediction_rows([rows[i] for i in ix],y[ix],prob))
                    metrics.append(dict(variant=variant,seed=seed,split=name,total_parameters=backbone+model.count_params(),**scores(y[ix],prob)))
        write_csv(out/'metrics.csv',metrics)
        print('Reference complete. Selected on validation:',choice,flush=True)

if __name__=='__main__':
    tf.keras.utils.set_random_seed(42);tf.config.experimental.enable_op_determinism();main()
