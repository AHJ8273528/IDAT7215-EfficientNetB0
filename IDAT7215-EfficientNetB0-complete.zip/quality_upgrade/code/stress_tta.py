"""Fixed seven-condition image stress test of single vs mirror-averaged B0."""
import argparse,json,sys,time
from pathlib import Path
import cv2,numpy as np,tensorflow as tf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'code'))
from experiment import dataset,pixels,write_csv,save_json,scores,prediction_rows
CONDITIONS=['clean','brightness0.5','brightness1.5','blur9_sigma2.0','jpeg_quality15','resize56','rotate10_reflect']
def transform(images,condition):
    if condition=='clean':return images
    if condition.startswith('brightness'):return np.clip(images.astype(np.float32)*float(condition.removeprefix('brightness')),0,255).astype(np.uint8)
    if condition=='blur9_sigma2.0':return np.array([cv2.GaussianBlur(im,(9,9),2.0) for im in images])
    if condition=='resize56':return np.array([cv2.resize(cv2.resize(im,(56,56)),(224,224)) for im in images])
    if condition=='rotate10_reflect':
        mat=cv2.getRotationMatrix2D((111.5,111.5),10,1)
        return np.array([cv2.warpAffine(im,mat,(224,224),borderMode=cv2.BORDER_REFLECT_101) for im in images])
    if condition=='jpeg_quality15':
        result=[]
        for im in images:
            ok,encoded=cv2.imencode('.jpg',cv2.cvtColor(im,cv2.COLOR_RGB2BGR),[cv2.IMWRITE_JPEG_QUALITY,15]);assert ok
            result.append(cv2.cvtColor(cv2.imdecode(encoded,cv2.IMREAD_COLOR),cv2.COLOR_BGR2RGB))
        return np.asarray(result)
    raise ValueError(condition)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',required=True,type=Path);p.add_argument('--root',type=Path,default=ROOT);a=p.parse_args();r=a.root
    out=r/'quality_upgrade/stress';out.mkdir(parents=True,exist_ok=True)
    rows,paths,y,split=dataset(a.data,r/'manifests','three')
    model=tf.keras.models.load_model(r/'models/three_selected_seed42.keras',compile=False)
    @tf.function(input_signature=[tf.TensorSpec((None,224,224,3),tf.float32)])
    def infer(x):return model(x,training=False)
    metrics=[];predictions=[];views=[]
    for splitname in ['validation','test']:
        ix=split[splitname];images=pixels([paths[i] for i in ix]).astype(np.uint8)
        for condition in CONDITIONS:
            path=out/f'{splitname}_{condition}_views.npz'
            if path.exists():probs=np.load(path)['probabilities']
            else:
                changed=transform(images,condition);probs=np.empty((len(ix),2,2),np.float32)
                for first in range(0,len(ix),20):
                    x=changed[first:first+20].astype(np.float32)
                    joint=np.concatenate([x,x[:,:,::-1,:]],axis=0);p=infer(joint).numpy();n=len(x)
                    probs[first:first+n,0]=p[:n];probs[first:first+n,1]=p[n:]
                np.savez_compressed(path,probabilities=probs)
            assert probs.shape==(len(ix),2,2) and np.isfinite(probs).all()
            for strategy,p in [('single',probs[:,0]),('mirror_tta',probs.mean(axis=1))]:
                metrics.append(dict(split=splitname,condition=condition,strategy=strategy,**scores(y[ix],p)))
                predictions.extend(dict(split=splitname,condition=condition,strategy=strategy,**v) for v in prediction_rows([rows[i] for i in ix],y[ix],p))
            for view in range(2):views.extend(dict(split=splitname,condition=condition,view=['original','mirror'][view],**v) for v in prediction_rows([rows[i] for i in ix],y[ix],probs[:,view]))
            print('STRESS',splitname,condition,'single',metrics[-2]['accuracy'],'TTA',metrics[-1]['accuracy'],flush=True)
        if splitname=='validation':
            agg={}
            for strategy in ['single','mirror_tta']:
                m=[x for x in metrics if x['strategy']==strategy]
                agg[strategy]=dict(mean_f1=float(np.mean([x['f1'] for x in m])),worst_recall=min(x['recall'] for x in m),clean_f1=next(x['f1'] for x in m if x['condition']=='clean'))
            b,c=agg['single'],agg['mirror_tta']
            adopted=c['mean_f1']>=b['mean_f1']+.005 and c['clean_f1']>=b['clean_f1'] and c['worst_recall']>=b['worst_recall']
            save_json(out/'selection.json',dict(adopt_tta=adopted,selected='mirror_tta' if adopted else 'single',validation=agg,rule='mean7-condition validation F1 improves>=0.005; no clean F1 drop; no worst-condition recall drop',scope='Synthetic stress on previously known validation data; not external operational calibration. Selection fixed before computing test stress predictions.'))
            write_csv(out/'validation_metrics.csv',metrics)
    write_csv(out/'metrics.csv',metrics);write_csv(out/'predictions.csv',predictions);write_csv(out/'per_view_predictions.csv',views)
    for path in out.glob('*_views.npz'):path.unlink()
if __name__=='__main__':main()
