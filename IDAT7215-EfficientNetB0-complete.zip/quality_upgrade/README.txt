本轮增强版（v2）：正确基线、真实耗时、清晰度拒判原型

现在更扎实的结论
1. 补做官方正确[-1,1]预处理的InceptionResNetV2，和B0处于同一个TensorFlow/Keras环境。两种Inception头×3种子，共6次新训练；同一个StudyThree1557张名单、1089/159/309划分、Adam0.001、30轮、批30、冻结主干。
   Inception AP4平均97.84%；GAP+固定归一化平均99.57%；验证集选出gap_norm。B0 GAP+norm三种子均100%。这里的优势为0.43个百分点；不能继续只用对方原始97.09%作为唯一比较。
2. 同CPU、同20张图、各模型60次计时（5次预热，随机交错执行）：B0中位数18.59ms，正确预处理Inception为77.33ms，局部中位延迟比4.16倍。输入224、单张，计入CNN和分类头、不计读文件和缩放。这是本机微基准，不保证别的设备也有相同比率。参数4,131,685对54,435,234，少92.41%。
3. 补齐GAP头在StudyOne圆柱数据上的30次随机／时间重训。随机平均99.45%，时间块94.69%，时间块缺陷召回89.60%；早期块73.47%。AP4对应时间准确率95.65%、Recall97.87%。这是头结构在圆柱域逐折重训的比较，不是把已训练的StudyThree模型拿到新工件外测。主模型的测试满分仍有条件。
4. 两视角镜像平均未通过验证集预定规则：七种条件验证平均F1由0.9262降到0.9037，最差Recall0.5769降到0.5000。因此仍用单视角；不根据测试结果倒选增强方式。

新增的可演示功能：图片太模糊时请求重拍
质量分数采用224灰度Laplacian方差／平均亮度平方。只用干净验证集确定阈值0.2450452563，并在验证集按预定规则检查是否值得启用。没有新增CNN参数；增加一个验证集确定的阈值。低分输入返回needs_retake，既不输出缺陷类别，也不算识别正确。
测试探针：309张原测试图的7个条件，共2163个图像版本，并非2163个独立原图。始终分类错160/2163，错误率7.40%。质量门接受1166/2163（53.91%覆盖），其中错20/1166（1.72%接受样本错误率），其余997次要求重拍。干净图接受287/309（92.88%），22张干净图也被拒绝。模糊、低分辨率和旋转条件全部被拒；JPEG错误没有得到解决。质量门牺牲覆盖率，不能称全部输入准确率提高到98.28%。这是一项有明显成本的研究原型，不能直接作为实际工厂部署保证。
扩展设计发生在先前压力测试已知之后，尽管阈值与启用规则只用验证集，这仍是探索性评估，不是全新盲测。不同背景、相机或物体需要重新校准和独立外测。

如何用
查看全部现成证据：quality_upgrade/summary.json、corrected_inception/metrics.csv、benchmark/raw_timings.csv、stress/metrics.csv、quality_gate/metrics.csv、gap_temporal_validation/summary.csv。
    python main.py --verify
普通原始推理仍为根目录code/predict.py。可选质量检查演示：
    python quality_upgrade/code/predict_checked.py --image YOUR_IMAGE.jpg
主模型不变，输入仍是RGB0–255。拒判时程序在加载TensorFlow模型前返回，便于演示流程。

重跑扩展（先完成根目录code/run_all.py，数据/特征路径按实际填写）
    python quality_upgrade/code/run_upgrade.py --data work/data --b0-cache work/features --cache work/reference_features --keras-home work/keras_cache
官方参考权重约209MiB，下载后校验MD5；不放入ZIP。特征缓存也不交付，程序会重建。新输出目录可用--root指向已完成核心实验的rerun/。Notebook新增可选扩展单元，本机已执行所有实验程序，Notebook未在远程Colab重跑。

报告与PPT
根目录report_section.txt和speaking_script.txt更新为本轮证据。EfficientNetB0_presentation_v2_final.pptx为新版两页，图表可编辑；页脚还需真实演讲者姓名。旧版保留作记录，不要混用旧速度和新速度结果。
本轮共新增36次训练；连同原117次主训练和60次时间实验，累计213次。quality_upgrade/verification.json用独立标准库程序复算新指标、概率平均、阈值和耗时。报告应如实注明助手支持与既有方法来源。

方法来源
Keras官方Inception预处理：https://keras.io/api/applications/inceptionresnetv2/inception_resnet_v2_preprocessing/
OpenCV Laplacian算子：https://docs.opencv.org/4.x/d5/db5/tutorial_laplace_operator.html
亮度归一化分数、阈值和启用规则为本项目的工程选择，不声称OpenCV官方推荐这套拒判标准或全局首创。
