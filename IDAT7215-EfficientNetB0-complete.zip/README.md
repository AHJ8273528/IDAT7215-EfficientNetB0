# EfficientNetB0 for 3D-printed object defect classification

IDAT7215 · Group8 · EfficientNetB0 contribution

A small frozen ImageNet backbone, reproducible three-study experiments, and a matched-control robustness extension. Outputs are **normal/defect image labels**, not defect bounding boxes.

![Matched robustness experiment](figures/robustness_comparison.png)

## Main result: robustness at the same model size

The new StudyThree extension compares two freshly trained arms with identical initial head weights, training-image order and optimizer budgets. One arm trains on clean images; the other samples clean, blur, JPEG compression, downsampling or rotation views. We adopted augmentation using the fixed validation rule before this extension's test feature extraction.

| Test condition | Clean-training control | Robustness training |
|---|---:|---:|
| Clean | 99.78% | **100.00%** |
| Dark | **99.89%** | 99.57% |
| Bright | 98.38% | **99.14%** |
| Blur | 73.79% | **99.89%** |
| JPEG quality15 | 92.77% | **98.81%** |
| Downsample to56 | 88.78% | **100.00%** |
| Rotate10° | 90.18% | **100.00%** |
| Mean over seven conditions | 91.94% | **99.63%** |

Each value is the mean across seeds42/43/44 on the same309 test images. The selected model uses **4,131,685 parameters**, one original view, and100% prediction coverage. There is no quality rejection, ensemble or test-time augmentation in this table. [Per-condition means and sample SD](robustness_upgrade/summary.csv) · [Fixed protocol](robustness_upgrade/protocol.json) · [Validation selection](robustness_upgrade/selection.json)

**Scope:** This is an exploratory extension designed after earlier public stress tests were inspected. The corruption types and strengths overlap training and testing. These are not blind tests or independent print runs, and309×7×3 predictions are not6489 independent images. The dark-image tradeoff is reported above. The extension only concerns StudyThree; original StudyOne selections are unchanged.

## Original three-study results

| Study | Images: train / validation / test | Validation-selected B0 | Accuracy, three-seed mean | Defect recall |
|---|---|---|---:|---:|
| One: original cylinders |189 /27 /55|AP4, Adam|99.39%|100.00%|
| Two: supplied augmented data |2111 /308 /598|AP4, Adam|99.83%|99.49%|
| Three: public printing-defect data |1089 /159 /309|GAP+norm, Adam|100.00%|100.00%|

The original StudyOne GAP+norm ablation also scored100% across all three seeds, but was not the default selected under the original validation tie-breaking rule. It is not substituted after reading test outcomes. [All original means and SDs](three_seed_summary.csv)

![Three-study comparison](figures/three_study_comparison.png)

## Read and audit the evidence

Python3.12 is the reference environment. Inspection and metric verification need only the standard library:

```sh
git clone https://github.com/AHJ8273528/IDAT7215-EfficientNetB0.git
cd IDAT7215-EfficientNetB0
python3 unpack_evidence.py
python3 main.py --verify
python3 robustness_upgrade/verify_robustness.py
```

`full_evidence.zip` contains all per-image predictions, splits, histories and metric records for the original studies, temporal validation, corrected reference, stress tests, quality gate and the robustness extension. `unpack_evidence.py` checks its SHA-256 and only creates missing text evidence files. Historical quality-gate results are separate from the new robustness experiment.

## Predict an image

```sh
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python code/predict.py --model robustness_selected_seed42.keras --image YOUR_IMAGE.jpg
```

The supplied model is fixed seed42 of the validation-selected robustness arm. Input is OpenCV-resized224×224 RGB float32 in[0,255], with no external division by255. Output order is `normal=0, defect=1`; the positive defect threshold is0.5, with exact ties assigned normal. See [reload and parameter checks](robustness_upgrade/model_checks.json).

## Reproduce training

```sh
python code/prepare_data.py --data work/data
python code/experiment.py --data work/data --cache work/features --stage cache --study three
python robustness_upgrade/run_robustness.py --data work/data --base-cache work/features --cache work/robust_features --output work/robust_reproduced
python robustness_upgrade/verify_robustness.py
```

The last command audits the supplied evidence after unpacking. `--output work/robust_reproduced` preserves supplied results; its output contains new histories, predictions, selection and a full checkpoint. The cache command extracts StudyThree features without retraining the original models. The robustness extension adds six fits: two arms×three seeds, each30epochs, batch30, Adam0.001,1110updates. Original full-core reproduction into a separate tree is available through `code/run_all.py`; see `quality_upgrade/README.txt` for the optional earlier extension. Public data and ImageNet weights download on first use. No original photographs or unrelated local files are committed.

## What the additional validation shows

The repository includes time-block evaluation, perceptual similarity screening, cross-dataset transfer and a corrected InceptionResNetV2 reference. Time-block and cross-domain results expose weaknesses hidden by near-perfect random image splits. Similarity is a warning signal, not proof that a physical print appears in multiple partitions. The optional earlier sharpness gate rejects some images; rejected images are never counted as correct. Read [earlier analysis and limitations](quality_upgrade/README.txt).

## Attribution and course use

Public data and the paper: [AMdataset](https://github.com/mahsan2/AMdataset), [published study](https://doi.org/10.1016/j.eswa.2024.124293). Shared splits and asset inventory: [RachelYim67's group repository](https://github.com/RachelYim67/IDAT7215-3D-Defect-Detection). VGG16 comparison: [dustilayer's StudyOne repository](https://github.com/dustilayer/IDAT7215-VGG16-Study-One). Third-party evidence is attributed and keeps its original label encoding.

This work includes AI-assisted code and writing. The student must understand and verify it and follow the course's independent-coding and declaration rules. See [ATTRIBUTION.txt](ATTRIBUTION.txt). This is an individual experimental contribution; the group's report, personal contribution statement, named presentation and final submission still need integration.
